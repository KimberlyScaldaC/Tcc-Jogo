using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class InventarioBau : MonoBehaviour
{
    public GameObject inventarioUI;

    // Abre o invent�rio
    public void Abrir()
    {
        inventarioUI.SetActive(true);
    }

    // Fecha o invent�rio
    public void Fechar()
    {
        inventarioUI.SetActive(false);
    }
}


//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using TMPro;

//public class InventarioBau : MonoBehaviour
//{
//    public Transform slotsParent;  // Objeto que ter� os slots
//    public GameObject slotPrefab;  // Prefab de um slot com Image/Text

//    private List<GameObject> slots = new List<GameObject>();

//    // Lista de itens armazenados no invent�rio (simples: string = nome do item)
//    private List<string> items = new List<string>();

//    void Start()
//    {
//        // Cria 10 slots por padr�o
//        for (int i = 0; i < 10; i++)
//        {
//            GameObject slot = Instantiate(slotPrefab, slotsParent);
//            slots.Add(slot);
//        }
//        UpdateUI();
//    }

//    // Adicionar item ao invent�rio
//    public void AddItem(string itemName)
//    {
//        if (items.Count < slots.Count)
//        {
//            items.Add(itemName);
//            UpdateUI();
//        }
//        else
//        {
//            Debug.Log("Invent�rio cheio!");
//        }
//    }

//    // Atualizar o texto/imagem dos slots
//    void UpdateUI()
//    {
//        for (int i = 0; i < slots.Count; i++)
//        {
//            TMP_Text txt = slots[i].GetComponentInChildren<TMP_Text>();
//            if (i < items.Count)
//            {
//                txt.text = items[i];
//            }
//            else
//            {
//                txt.text = "";
//            }
//        }
//    }
//}
