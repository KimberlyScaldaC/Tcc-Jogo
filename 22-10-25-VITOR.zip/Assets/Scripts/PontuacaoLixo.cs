﻿using System.Collections.Generic;

public static class PontuacaoLixo
{
    // Dicionário: TipoLixo → Pontos base
    private static readonly Dictionary<TipoLixo, int> pontuacaoBase = new Dictionary<TipoLixo, int>
    {
        { TipoLixo.Papel, 100 },
        { TipoLixo.Plastico, 150 },
        { TipoLixo.Vidro, 200 },
        { TipoLixo.Metal, 300 },
        { TipoLixo.Madeira, 120 },
        { TipoLixo.Organico, 20 },
        { TipoLixo.Pilha, 400 },
        { TipoLixo.Eletronico, 1000 }
    };

    public static int GetPontos(TipoLixo tipo)
    {
        if (pontuacaoBase.ContainsKey(tipo))
            return pontuacaoBase[tipo];
        return 0;
    }
}
