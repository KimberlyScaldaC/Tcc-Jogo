﻿using UnityEngine;
using TMPro;

public class SistemaDiaNoite : MonoBehaviour
{
    public static SistemaDiaNoite instancia;

    [Header("Relógio e Ciclo")]
    public TextMeshProUGUI relogioText;
    public float tempoPorSegundos = 10f;
    public SpriteRenderer[] ceus;
    public Color corDia = Color.cyan;
    public Color corNoite = Color.black;

    [HideInInspector] public int hora = 6;
    [HideInInspector] public int minuto = 0;

    private float timer = 0f;
    public bool ehDia => hora >= 6 && hora < 18;
    public bool ehNoite => hora >= 18 && hora < 6;

    [Header("Fim do dia - Pop-up")]
    

    [Header("Resumo do dia")]
    public int lixoReciclado;
    public int materiasPrimasGanhas;
    public int pontosTotal;

    public int madeira = 0;
    public int papel = 0;
    public int plastico = 0;
    public int metal = 0;
    public int vidro = 0;
    public int pilha = 0;
    public int organico = 0;
    public int eletronico = 0;


    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= tempoPorSegundos)
        {
            timer = 0f;
            IncrementarHora(1);
        }
        
    }

    public void IncrementarHora(int minutos)
    {
        minuto = minuto+ minutos;
        if (minuto >= 60)
        {
            hora += minuto / 60;
            minuto %= 60;
            if (hora >= 24)
            {
                hora %= 24;
            }  
        }
        AtualizarRelogio();
        AtualizarCeu();
    }

    public void AtualizarRelogio()
    {
        relogioText.text = string.Format("{0:00}:{1:00}", hora, minuto);
    }

    public void AtualizarCeu()
    {
        Color corAtual = ehDia ? corDia : corNoite;
        foreach (var c in ceus)
        {
            c.color = corAtual;
        }
    }

    // Método público para chamar quando o jogador dorme
    public void Dormir()
    {
        // avança o tempo para manhã (6h00)
        hora = 6;
        minuto = 0;
        AtualizarRelogio();
        AtualizarCeu();
    }




    // =================== Adicionar pontos ===================

    /*
     fiz um jog na unity em 2d em pixel art e tenho 3 cenas e 1 que é a intro a 2 que é o jogo e a 3 que é uma historinha essa historinha tinha que aparecer somente uma vez so quando o jogador coloca o lixo eletronico na caixa de eletronicos e so iria aparecer quando o rologio do jogo da 18h e eu quero tbm tem umas variaveis ue eu preciso guarda os valores dela pq quando troca de cena pra loja de eletronicos e volta pro jogo tem que continua da onde parou
     */
}
