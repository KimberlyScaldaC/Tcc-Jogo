using UnityEngine;
using UnityEngine.SceneManagement;

public class HistorinhaChecker : MonoBehaviour
{
    void Update()
    {
        if (GameManager.instancia.lixoEletronicoNaCaixa
            && SistemaDiaNoite.instancia.hora == 18
            && !GameManager.instancia.historinhaMostrada)
        {
            Debug.Log("HistorinhaChecker");
            GameManager.instancia.historinhaMostrada = true;
            GameManager.instancia.SalvarProgresso();
            var asyncLoad = SceneManager.LoadSceneAsync("Scenes/LojaEletronicos", LoadSceneMode.Additive);
            asyncLoad.completed += (op) =>
            {
                Scene lojaScene = SceneManager.GetSceneByName("LojaEletronicos");
                SceneManager.SetActiveScene(lojaScene);
            };

        }
    }
}
