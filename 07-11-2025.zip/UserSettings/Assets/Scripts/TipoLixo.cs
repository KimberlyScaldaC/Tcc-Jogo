using UnityEngine;

public enum TipoLixo
{
    Eletronico,  // Caixa
    Papel,       // Azul
    Plastico,    // Vermelho
    Vidro,       // Verde
    Metal,       // Amarelo
    Madeira,     // Preto
    Pilha,       // Laranja
    Organico     // Marrom
}
