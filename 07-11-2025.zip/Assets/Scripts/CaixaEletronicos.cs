using UnityEngine;
using UnityEngine.SceneManagement;

public class CaixaEletronicos : MonoBehaviour
{
    public static CaixaEletronicos instancia;

    [Header("Sprites da Caixa")]
    public Sprite caixaVazia;
    public Sprite caixaCheia;

    private SpriteRenderer spriteRenderer;

    void Awake()
    {
        instancia = this;
    }

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        EsvaziarCaixa(); // come�a vazia
    }

    // Coloca a caixa como cheia
    public void EncherCaixa()
    {
        if (spriteRenderer != null && caixaCheia != null)
        {
            spriteRenderer.sprite = caixaCheia;
        }
        else
        {
            Debug.LogWarning("SpriteRenderer ou caixaCheia n�o atribu�dos!");
        }
    }

    // Coloca a caixa como vazia
    public void EsvaziarCaixa()
    {
        if (spriteRenderer != null && caixaVazia != null)
        {
            spriteRenderer.sprite = caixaVazia;
        }
        else
        {
            Debug.LogWarning("SpriteRenderer ou caixaVazia n�o atribu�dos!");
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        EsvaziarCaixa();
        LixoColetavel lixo = other.GetComponent<LixoColetavel>();
        if (lixo != null && lixo.tipo == TipoLixo.Eletronico)
        {
            if (SistemaDiaNoite.instancia.hora == 18 && !GameManager.instancia.historinhaMostrada)
            {
                GameManager.instancia.historinhaMostrada = true;
                GameManager.instancia.SalvarProgresso();
                SceneManager.LoadScene("Scenes/LojaEletronicos");
            }
        }
    }
}
