using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ComputerShop : MonoBehaviour
{
    public static ComputerShop instancia;

    [Header("Refer�ncias")]
    public GameObject[] slotExtras; // arraste aqui no inspector os 6 slots extras
    public PlayerController playerController;
    public InventarioPlayer inventario; // se tiver script de invent�rio
    public GameObject shopComputer;

    [Header("Refer�ncias dos itens")]
    public GameObject telaComputador;  // Tela ligada/desligada
    public GameObject tenis;
    public GameObject slot1;
    public GameObject slot2;
    public GameObject slot3;

    [Header("Bot�es de compra")]
    public Button botaoComputador;
    public Button botaoTenis;
    public Button botaoSlot1;
    public Button botaoSlot2;
    public Button botaoSlot3;

    [Header("Textos de pre�o")]
    public TextMeshProUGUI precoComputadorText;
    public TextMeshProUGUI precoTenisText;
    public TextMeshProUGUI precoSlot1Text;
    public TextMeshProUGUI precoSlot2Text;
    public TextMeshProUGUI precoSlot3Text;

    [Header("Pre�os dos itens")]
    public int precoComputador = 500;
    public int precoTenis = 200;
    public int precoSlot1 = 300;
    public int precoSlot2 = 400;
    public int precoSlot3 = 500;

    [Header("Atributos extras")]
    public float bonusVelocidade = 5f;
    public int slotsExtras = 2;

    private bool computadorComprado = false;

    private void Awake()
    {
        instancia = this;
    }

    private void Start()
    {
        // Define textos de pre�o
        precoComputadorText.text = "Pontua��o: " + precoComputador;
        precoTenisText.text = "Pontua��o: " + precoTenis;
        precoSlot1Text.text = "Pontua��o: " + precoSlot1;
        precoSlot2Text.text = "Pontua��o: " + precoSlot2;
        precoSlot3Text.text = "Pontua��o: " + precoSlot3;

        // Liga os bot�es
        botaoComputador.onClick.AddListener(() => ComprarItem("Computador"));
        botaoTenis.onClick.AddListener(() => ComprarItem("Tenis"));
        botaoSlot1.onClick.AddListener(() => ComprarItem("Slot1"));
        botaoSlot2.onClick.AddListener(() => ComprarItem("Slot2"));
        botaoSlot3.onClick.AddListener(() => ComprarItem("Slot3"));

        AtualizarDisponibilidade();
    }

    private void Update()
    {
        AtualizarDisponibilidade();
    }

    private void AtualizarDisponibilidade()
    {
        int pontos = GerenciadorPontuacao.instancia.GetPontuacao();

        // Bot�o do computador sempre aparece se ainda n�o foi comprado
        botaoComputador.gameObject.SetActive(!computadorComprado);
        botaoComputador.interactable = pontos >= precoComputador && !computadorComprado;

        // T�nis sempre dispon�vel para compra
        botaoTenis.interactable = pontos >= precoTenis;

        // Slots s� ficam dispon�veis ap�s comprar o computador
        bool liberar = computadorComprado;

        botaoTenis.gameObject.SetActive(liberar);
        botaoSlot1.gameObject.SetActive(liberar);
        botaoSlot2.gameObject.SetActive(liberar);
        botaoSlot3.gameObject.SetActive(liberar);

        botaoTenis.interactable = liberar && pontos >= precoTenis;
        botaoSlot1.interactable = liberar && pontos >= precoSlot1;
        botaoSlot2.interactable = liberar && pontos >= precoSlot2;
        botaoSlot3.interactable = liberar && pontos >= precoSlot3;
    }

    private void ComprarItem(string item)
    {
        int pontos = GerenciadorPontuacao.instancia.GetPontuacao();

        switch (item)
        {
            case "Computador":
                if (pontos >= precoComputador)
                {
                    GerenciadorPontuacao.instancia.AdicionarPontos(-precoComputador);
                    computadorComprado = true;
                    MesaDeTrabalho.instancia.mesaComprada = true;

                    if (telaComputador != null)
                        telaComputador.SetActive(false);

                    Debug.Log("Computador comprado!");
                }
                else Debug.Log("Sem pontos suficientes!");
                break;

            case "Tenis":
                if (pontos >= precoTenis)
                {
                    GerenciadorPontuacao.instancia.AdicionarPontos(-precoTenis);
                    tenis.SetActive(false);
                    AumentarVelocidadeJogador();
                }
                else Debug.Log("Sem pontos suficientes!");
                break;

            case "Slot1":
                if (pontos >= precoSlot1)
                {
                    GerenciadorPontuacao.instancia.AdicionarPontos(-precoSlot1);
                    slot1.SetActive(false);
                    InventarioPlayer.instancia.AdicionarSlots(2);
                }
                else Debug.Log("Sem pontos suficientes!");
                break;

            case "Slot2":
                if (pontos >= precoSlot2)
                {
                    GerenciadorPontuacao.instancia.AdicionarPontos(-precoSlot2);
                    slot2.SetActive(false);
                    InventarioPlayer.instancia.AdicionarSlots(2);
                }
                else Debug.Log("Sem pontos suficientes!");
                break;

            case "Slot3":
                if (pontos >= precoSlot3)
                {
                    GerenciadorPontuacao.instancia.AdicionarPontos(-precoSlot3);
                    slot3.SetActive(false);
                    InventarioPlayer.instancia.AdicionarSlots(2);
                }
                else Debug.Log("Sem pontos suficientes!");
                break;
        }
    }

    private int RetornarPreco(string item)
    {
        return item switch
        {
            "Tenis" => precoTenis,
            "Slot1" => precoSlot1,
            "Slot2" => precoSlot2,
            "Slot3" => precoSlot3,
            _ => 0
        };
    }

    private void DesativarItem(string item)
    {
        switch (item)
        {
            case "Tenis": tenis.SetActive(false); break;
            case "Slot1": slot1.SetActive(false); break;
            case "Slot2": slot2.SetActive(false); break;
            case "Slot3": slot3.SetActive(false); break;
        }


    }

    private void AumentarVelocidadeJogador()
    {
        PlayerController jogador = FindObjectOfType<PlayerController>();
        if (jogador != null)
        {
            jogador.speed += 2f; // aumenta a velocidade em 2
            Debug.Log("Velocidade aumentada! Nova velocidade: " + jogador.speed);
        }
    }

}
