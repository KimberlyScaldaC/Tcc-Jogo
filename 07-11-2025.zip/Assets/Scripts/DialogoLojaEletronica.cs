﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogoLojaEletronica : MonoBehaviour
{
    public static DialogoLojaEletronica instancia;

    [Header("Interface de História")]
    public GameObject historiaPanel;      // painel do diálogo
    public TextMeshProUGUI falaText;      // texto da fala
    public Button nextButton;             // botão Next
    public Button skipButton;             // botão Skip

    [TextArea(3, 10)]
    public string[] falas = {
        "Bem-vindo à loja de eletrônicos!",
        "Aqui você pode reciclar equipamentos eletrônicos."
    };

    private int falaIndex = 0;
    private bool historiaAtiva = false;
    private bool historiaJaAconteceu = false;

    void Start()
    {
        historiaPanel.SetActive(false);
        nextButton.onClick.AddListener(ProximaFala);
        skipButton.onClick.AddListener(EncerrarHistoria);
    }

    // 🔹 Esse método será chamado pela Lixeira quando o jogador colocar o lixo eletrônico
    public void IniciarHistoria()
    {
        // garante que só acontece uma vez
        if (historiaAtiva || historiaJaAconteceu) return;

        Debug.Log("Iniciou a história da loja de eletrônicos!");
        historiaAtiva = true;
        historiaJaAconteceu = true;

        // mostra a primeira fala
        falaIndex = 0;
        falaText.text = falas[falaIndex];
        historiaPanel.SetActive(true);

        // pausa o jogo
        Time.timeScale = 0f;
    }

    public void ProximaFala()
    {
        falaIndex++;
        if (falaIndex < falas.Length)
        {
            falaText.text = falas[falaIndex];
        }
        else
        {
            EncerrarHistoria();
        }
    }

    public void EncerrarHistoria()
    {
        historiaPanel.SetActive(false);
        historiaAtiva = false;

        // retoma o jogo
        Time.timeScale = 1f;
    }
}
