using UnityEngine;

public class MesaDeTrabalho : MonoBehaviour
{
    public static MesaDeTrabalho instancia;

    [Header("Refer�ncia ao painel da loja")]
    public GameObject painelLoja;

    [Header("Controle da compra da mesa")]
    public bool mesaComprada = false;

    public GameObject balao;
    

    private bool jogadorPerto = false;

    private void Awake()
    {
        instancia = this;
    }

    void Start()
    {
        if (painelLoja != null)
            painelLoja.SetActive(false);
    }

    void Update()
    {
        if (jogadorPerto)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                OpenMenuLoja();
            }

            if (Input.GetKeyDown(KeyCode.X))
            {
                CloseMenuLoja();
            }
        }
    }

    public void OpenMenuLoja()
    {
        if (!mesaComprada)
        {
            // Se quiser mostrar um bal�o ou mensagem de aviso:
            if (BalaoMensagem.instancia != null)
                BalaoMensagem.instancia.MostrarMensagem("Mesa ainda n�o comprada!");

            return; // Sai sem abrir
        }
        balao.SetActive(false);
        painelLoja.SetActive(true);
    }

    public void CloseMenuLoja()
    {
        painelLoja.SetActive(false);
    }

    void OnTriggerEnter2D(Collider2D outro)
    {
        if (outro.CompareTag("Personagem"))
            jogadorPerto = true;
    }

    void OnTriggerExit2D(Collider2D outro)
    {
        if (outro.CompareTag("Personagem"))
        {
            jogadorPerto = false;
            if (painelLoja != null)
                painelLoja.SetActive(false); // fecha ao sair
        }
    }
}
