using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class FimDiaPop : MonoBehaviour
{
    //public static FimDiaPop instancia;

    //public GameObject painelPop;
    //public TextMeshProUGUI textoResumo;
    //public Button botaoContinuar;

    //private void Awake()
    //{
    //    if (instancia == null) instancia = this;
    //    else Destroy(gameObject);

    //    if (painelPop != null)
    //        painelPop.SetActive(false);

    //    if (botaoContinuar != null)
    //        botaoContinuar.onClick.AddListener(Continuar);
    //}

    //public void MostrarResumo(string resumo)
    //{
    //    if (painelPop == null || textoResumo == null) return;

    //    painelPop.SetActive(true);
    //    textoResumo.text = resumo;
    //}

    //private void Continuar()
    //{
    //    painelPop.SetActive(false);
    //    SistemaDiaNoite.instancia.ContinuarJogo();
    //}
}