using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainHistoria : MonoBehaviour
{

    public GameObject menuUI; // aqui voc� vai arrastar o Canvas
    public GameObject storyManagerObj;

    void Start()
    {
        menuUI.SetActive(true);       // mostra menu
        storyManagerObj.SetActive(false); // esconde painel de di�logo
    }

    public void PlayGame()
    {
        menuUI.SetActive(false);       // esconde menu
        storyManagerObj.SetActive(true); // mostra painel de di�logo
    }

    // Bot�o Settings
    public void OpenSettings()
    {
        Debug.Log("Abrindo Configura��es...");
        // Aqui voc� pode abrir um painel de op��es futuramente
    }

    // Bot�o Exit
    public void QuitGame()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit();

        // No editor n�o fecha, mas voc� v� a mensagem no Console
    }
}


