﻿using System.Collections.Generic;

public static class PontuacaoLixo
{
    // Dicionário: TipoLixo → Pontos base
    private static readonly Dictionary<TipoLixo, int> pontuacaoBase = new Dictionary<TipoLixo, int>
    {
        { TipoLixo.Papel, 150 },
        { TipoLixo.Plastico, 300 },
        { TipoLixo.Vidro, 200 },
        { TipoLixo.Metal, 500 },
        { TipoLixo.Madeira, 250 },
        { TipoLixo.Organico, 100 },
        { TipoLixo.Pilha, 400 },
        { TipoLixo.Eletronico, 500 }
    };

    public static int GetPontos(TipoLixo tipo)
    {
        if (pontuacaoBase.ContainsKey(tipo))
            return pontuacaoBase[tipo];
        return 0;
    }
}
