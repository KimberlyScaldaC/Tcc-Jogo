using UnityEngine;
using UnityEngine.Tilemaps;

public class SpawnerLixo : MonoBehaviour
{
    public GameObject[] prefabsLixo;   // Todos os tipos de lixo
    public int altura = 3;             // Altura da pir�mide
    public int larguraBase = 5;        // Quantos lixos na linha da base
    public float espacoX = 1f;         // Espa�amento horizontal
    public float espacoY = 0.5f;       // Espa�amento vertical
    public Tilemap chaoTilemap;        // Refer�ncia ao Tilemap do ch�o
    public Vector3Int tileInicio;      // Tile do ch�o onde come�a a pir�mide

    void Start()
    {
        if (prefabsLixo.Length == 0 || chaoTilemap == null)
        {
            Debug.LogError("Prefabs ou Tilemap n�o est�o atribu�dos!");
            return;
        }

        // Pega posi��o do tile escolhido
        Vector3 basePos = chaoTilemap.CellToWorld(tileInicio);
        float alturaTile = chaoTilemap.cellSize.y;

        // Loop das camadas da pir�mide
        for (int i = 0; i < altura; i++)
        {
            int lixosNaLinha = larguraBase;
            float offsetX = -(lixosNaLinha - 1) * espacoX / 2f;

            for (int j = 0; j < lixosNaLinha; j++)
            {
                Vector3 spawnPos = new Vector3(
                    basePos.x + offsetX + j * espacoX,
                    basePos.y + i * espacoY + alturaTile / 2f, // ajusta Y para encostar no ch�o
                    0
                );

                int randomIndex = Random.Range(0, prefabsLixo.Length);
                GameObject lixoEscolhido = prefabsLixo[randomIndex];

                Instantiate(lixoEscolhido, spawnPos, Quaternion.identity);
            }
        }
    }
}

