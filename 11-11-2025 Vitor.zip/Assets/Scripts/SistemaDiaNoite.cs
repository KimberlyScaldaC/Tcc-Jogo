﻿using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class SistemaDiaNoite : MonoBehaviour
{
    public static SistemaDiaNoite instancia;

    [Header("Relógio e Ciclo")]
    public TextMeshProUGUI relogioText;
    public float tempoPorSegundos = 10f;
    public SpriteRenderer[] ceus;
    public Color corDia = Color.cyan;
    public Color corNoite = Color.black;

    [Header("UI do jogo")]
    public GameObject inventarioHUD;
    public GameObject menuResultadosDia;

    [HideInInspector] public int hora = 6;
    [HideInInspector] public int minuto = 0;

    private float timer = 0f;
    public bool ehDia => hora >= 6 && hora < 18;
    public bool ehNoite => hora >= 18 || hora < 6;

    [Header("Fim do dia - Pop-up")]
    public bool menuAberto = false;

    [Header("Resumo do dia")]
    public int lixoReciclado;
    public int materiasPrimasGanhas;
    public int pontosTotal;

    public int madeira = 0;
    public int papel = 0;
    public int plastico = 0;
    public int metal = 0;
    public int vidro = 0;
    public int pilha = 0;
    public int organico = 0;
    public int eletronico = 0;

    [Header("Historia da Loja Eletronicos")]
    public bool FecharHistoria = false;

    private void Awake()
    {
        if (instancia == null)
        {
            instancia = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= tempoPorSegundos)
        {
            timer = 0f;
            IncrementarHora(1);
        }

        if(ehDia && menuAberto)
        {
            menuAberto = false;
        }


        //RESOLVE VITO
        //VERIFICA SE DEVE MOSTRAR A HISTORINHA
        if (GameManager.instancia.lixoEletronicoNaCaixa
            && SistemaDiaNoite.instancia.hora == 18
            && !GameManager.instancia.historinhaMostrada)
        {
            inventarioHUD.SetActive(false);
            menuResultadosDia.SetActive(false);

            Debug.Log("SistemaDiaNoite");
            Debug.Log("HistorinhaChecker");


            GameManager.instancia.historinhaMostrada = true;
            GameManager.instancia.SalvarProgresso();

            Time.timeScale = 0f;
            //GameManager.instancia.NaoMostrarCoisa();
            //GameManager.instancia.inventarioHUD.SetActive(false);
            //GameManager.instancia.menuResultadosDia.SetActive(false);

            Debug.Log("FecharHistoria - " + FecharHistoria);
            var asyncLoad = SceneManager.LoadSceneAsync("Scenes/LojaEletronicos", LoadSceneMode.Additive);
            asyncLoad.completed += (op) =>
            {
                Scene lojaScene = SceneManager.GetSceneByName("LojaEletronicos");
                SceneManager.SetActiveScene(lojaScene);
                // FecharHistoria = true;
                Debug.Log("FecharHistoria - " + FecharHistoria);
            };
            if (FecharHistoria == true)
            {
                Debug.Log("História encerrada — retomando jogo.");

                // 🔹 Retoma o jogo
                Time.timeScale = 1f;

                // 🔹 Reativa os elementos da HUD
                ; ; GameManager.instancia.MostrarCoisa();

                inventarioHUD.SetActive(true);
                menuResultadosDia.SetActive(true);
                Debug.Log("FecharHistoria - " + FecharHistoria);
            }
            

        }


        if (hora == 18 && !menuAberto)
        {
          
            menuAberto = true;
            ResultadosDia.instancia.MostrarResultados();
            GameManager.instancia.MostrarPontos();
            GameManager.instancia.lixoEletronicoNaCaixa = false;
        }

    }

    public void IncrementarHora(int minutos)
    {
        minuto = minuto+ minutos;
        if (minuto >= 60)
        {
            hora += minuto / 60;
            minuto %= 60;
            if (hora >= 24)
            {
                hora %= 24;
            }  
        }
        AtualizarRelogio();
        AtualizarCeu();
    }

    public void AtualizarRelogio()
    {
        relogioText.text = string.Format("{0:00}:{1:00}", hora, minuto);
    }

    public void AtualizarCeu()
    {
        Color corAtual = ehDia ? corDia : corNoite;
        foreach (var c in ceus)
        {
            c.color = corAtual;
        }
    }

    // Método público para chamar quando o jogador dorme
    public void Dormir()
    {
        // avança o tempo para manhã (6h00)
        hora = 6;
        minuto = 0;
        AtualizarRelogio();
        AtualizarCeu();
    }

}
