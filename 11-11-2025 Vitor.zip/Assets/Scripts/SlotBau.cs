using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SlotBau : MonoBehaviour
{
    public static SlotBau instancia;

    [Header("UI do Slot")]
    public Image imagemItem;
    public TextMeshProUGUI txtNome;
    public TextMeshProUGUI txtQuantidade;

    [Header("Mat�ria-prima obtida")]
    public int madeira;
    public int plastico;
    public int papel;
    public int vidro;
    public int metal;
    public int eletronico;

    private void Awake()
    {
        if (instancia == null) instancia = this;
    }

    public void AtualizarSlot(Sprite sprite, string nome, int quantidade)
    {
        if (imagemItem == null || txtNome == null || txtQuantidade == null) return;

        if (sprite != null)
        {
            imagemItem.sprite = sprite;
            imagemItem.enabled = true;
        }
        else
        {
            imagemItem.enabled = false;
        }

        Debug.Log("ENTROU NO AtualizarSlot - " + nome + " - " + quantidade);
        

        switch (nome)
        {
            case "Madeira":
                madeira += quantidade;
                txtQuantidade.text = madeira.ToString();
                break;
            case "Pl�stico":
                plastico += quantidade;
                txtQuantidade.text = plastico.ToString();
                break;
            case "Papel":
                papel += quantidade;
                txtQuantidade.text = papel.ToString();
                break;
            case "Vidro":
                vidro += quantidade;
                txtQuantidade.text = vidro.ToString();
                break;
            case "Metal":
                metal += quantidade;
                txtQuantidade.text = metal.ToString();
                break;
            case "Eletr�nico":
                eletronico += quantidade;
                txtQuantidade.text = eletronico.ToString();
                break;
        }
        txtNome.text = nome;
        LojaMoveis.instancia.AtualizarMateriaPrima(nome, quantidade);
    }

    public void AtualizarSlotRetira(Sprite sprite, string nome, int quantidade)
    {
        if (imagemItem == null || txtNome == null || txtQuantidade == null) return;

        if (sprite != null)
        {
            imagemItem.sprite = sprite;
            imagemItem.enabled = true;
        }
        else
        {
            imagemItem.enabled = false;
        }




        switch (nome)
        {
            case "Madeira":
                madeira = quantidade;
                txtQuantidade.text = madeira.ToString();
                break;
            case "Pl�stico":
                plastico = quantidade;
                txtQuantidade.text = plastico.ToString();
                break;
            case "Papel":
                papel = quantidade;
                txtQuantidade.text = papel.ToString();
                break;
            case "Vidro":
                vidro = quantidade;
                txtQuantidade.text = vidro.ToString();
                break;
            case "Metal":
                metal = quantidade;
                txtQuantidade.text = metal.ToString();
                break;
            case "Eletr�nico":
                eletronico = quantidade;
                txtQuantidade.text = eletronico.ToString();
                break;
        }
        txtNome.text = nome;
        
    }

    public void ConsumirMateria(string nome, int quantidade)
    {
        Debug.Log("ENTROU NO ConsumirMateria - "+ nome+" - "+ quantidade);
        switch (nome)
        {
            case "Madeira":
                madeira -= quantidade;
                txtQuantidade.text = madeira.ToString();
                break;
            case "Pl�stico":
                plastico -= quantidade;
                txtQuantidade.text = plastico.ToString();
                break;
            case "Papel":
                papel -= quantidade;
                txtQuantidade.text = papel.ToString();
                break;
            case "Vidro":
                vidro -= quantidade;
                txtQuantidade.text = vidro.ToString();
                break;
            case "Metal":
                metal -= quantidade;
                txtQuantidade.text = metal.ToString();
                break;
            case "Eletr�nico":
                eletronico -= quantidade;
                txtQuantidade.text = eletronico.ToString();
                break;
        }
    }
}