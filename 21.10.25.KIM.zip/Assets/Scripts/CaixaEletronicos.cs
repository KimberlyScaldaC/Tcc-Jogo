using UnityEngine;
using UnityEngine.SceneManagement;

public class CaixaEletronicos : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        LixoColetavel lixo = other.GetComponent<LixoColetavel>();
        if (lixo != null && lixo.tipo == TipoLixo.Eletronico)
        {
            // Marca que o lixo eletr�nico foi colocado
            GameManager.instancia.lixoEletronicoNaCaixa = true;
            GameManager.instancia.SalvarProgresso();

            Debug.Log("Lixo eletr�nico colocado na caixa.");

            // Verifica se � 18h e a historinha ainda n�o foi mostrada
            if (SistemaDiaNoite.instancia.hora == 18 && !GameManager.instancia.historinhaMostrada)
            {
                GameManager.instancia.historinhaMostrada = true;
                GameManager.instancia.SalvarProgresso();
                SceneManager.LoadScene("CenaHistorinha");
            }

            // Desativa o lixo (remover do jogo)
            other.gameObject.SetActive(false);
        }
    }
}



/*using UnityEngine;
using UnityEngine.SceneManagement;

public class CaixaEletronicos : MonoBehaviour
{
    //public TipoLixo tipoAceito;
    //private SpriteRenderer spriteRenderer;
    //private Collider2D colisor;
    //private bool jogadorPerto = false;

    void Start()
    {
        //spriteRenderer = GetComponent<SpriteRenderer>();
        //colisor = GetComponent<Collider2D>();
    }

    void Update()
    {
        if (SistemaDiaNoite.instancia.hora == 18 && !GameManager.instancia.historinhaMostrada)
        {
            Debug.Log("CaixaEletronicos");
            GameManager.instancia.historinhaMostrada = true;
            GameManager.instancia.SalvarProgresso();
            SceneManager.LoadScene("Scenes/LojaEletronicos");
        }
        /*if (jogadorPerto && Input.GetKeyDown(KeyCode.E))
        {
            Debug.Log("CaixaEletronicos");
            InventarioPlayer inventarioPlayer = InventarioPlayer.instancia;
            LixoColetavel lixo = inventarioPlayer.itemSelecionado;


            if (inventarioPlayer == null)
            {
                Debug.LogError("InventarioPlayer.instancia est� null!");
                return;
            }

            //inventarioPlayer.AtualizarItemSelecionado();
            
            if (lixo == null)
            {
                Debug.LogWarning("Nenhum lixo selecionado no invent�rio.");
                return;
            }

            if (lixo.tipo == tipoAceito)
            {
                if (lixo.tipo == TipoLixo.Eletronico)
                {
                    // Marca que o lixo eletr�nico foi colocado
                    GameManager.instancia.lixoEletronicoNaCaixa = true;
                    GameManager.instancia.SalvarProgresso();

                    Debug.Log("Lixo eletr�nico colocado na caixa.");

                    // Verifica se � 18h e a historinha ainda n�o foi mostrada
                    /*if (SistemaDiaNoite.instancia.hora == 18 && !GameManager.instancia.historinhaMostrada)
                    {
                        GameManager.instancia.historinhaMostrada = true;
                        GameManager.instancia.SalvarProgresso();
                        SceneManager.LoadScene("Scenes/LojaEletronicos");
                    }

                    // Desativa o lixo (remover do jogo)
                    lixo.gameObject.SetActive(false);
                }
            }
            
            
            
        }*/

    }

    /*private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = false;
        }
    }*/
}
*/
