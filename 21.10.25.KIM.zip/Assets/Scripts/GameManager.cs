using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager instancia;

    public bool lixoEletronicoNaCaixa = false;
    public bool historinhaMostrada = false;

    private void Awake()
    {
        if (instancia == null)
        {
            instancia = this;
            DontDestroyOnLoad(gameObject);

            // Carregar progresso salvo
            lixoEletronicoNaCaixa = PlayerPrefs.GetInt("lixoEletronicoNaCaixa", 0) == 1;
            historinhaMostrada = PlayerPrefs.GetInt("historinhaMostrada", 0) == 1;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SalvarProgresso()
    {
        PlayerPrefs.SetInt("lixoEletronicoNaCaixa", lixoEletronicoNaCaixa ? 1 : 0);
        PlayerPrefs.SetInt("historinhaMostrada", historinhaMostrada ? 1 : 0);
        PlayerPrefs.Save();
    }
}
