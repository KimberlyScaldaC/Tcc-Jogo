﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class GerenciadorLixo : MonoBehaviour
{
    public static GerenciadorLixo instancia;

    [Header("Configurações")]
    public int totalLixosCena;
    public int lixosPegos = 0;
    public int pontuacaoTotal = 0;
    public bool jogoAtivo = false;

    [Header("Painel de Vitória")]
    public GameObject painelVitoria;
    public TextMeshProUGUI textoPontuacao;
    public Button botaoReiniciar;
    

    private void Awake()
    {
        instancia = this;
    }

    void Start()
    {
        painelVitoria.SetActive(false);
        if (botaoReiniciar != null)
            botaoReiniciar.onClick.AddListener(ReiniciarJogo);
    }

    public void RegistrarPonto(int ponto)
    {
        pontuacaoTotal = pontuacaoTotal + ponto;
    }

    public void RegistrarLixoSpawer(int total)
    {
        totalLixosCena = total;
    }

    public void RegistrarLixoColetado()
    {
        lixosPegos++;

        if (lixosPegos >= totalLixosCena)
        {
            jogoAtivo = true;
        }
    }

    public void MostrarPainelVitoria()
    {
        Time.timeScale = 0f; // pausa o jogo
        painelVitoria.SetActive(true);

        textoPontuacao.text = "" + pontuacaoTotal;
    }

    void ReiniciarJogo()
    {
        Time.timeScale = 1f; // retoma o tempo
        SceneManager.UnloadSceneAsync("Intro");
    }
}
