﻿using UnityEngine;

public class BoxController : MonoBehaviour
{
    public static BoxController instancia;

    public Animator animator;           // Animator do baú
    public GameObject inventarioBau;    // Painel de inventário

    private bool isOpen = false;
    private bool playerNearby = false;

    private void Awake()
    {
        instancia = this;
    }

    private void Start()
    {
        if (inventarioBau != null)
            inventarioBau.SetActive(false); ; // Começa invisível
    }

    public void Update()
    {
        if (playerNearby)
        {
            // Abrir baú
            if (Input.GetKeyDown(KeyCode.E) && !isOpen)
            {
                
                OpenBau();
            }

            // Fechar baú
            if (Input.GetKeyDown(KeyCode.X) && isOpen)
            {
                CloseBau();
            }
        }
    }

    public void OpenBau()
    {
        isOpen = true;
        animator.SetBool("isOpen", true);
        inventarioBau.SetActive(true);
    }

    public void CloseBau()
    {
        
        isOpen = false;
        animator.SetBool("isOpen", false);
        inventarioBau.SetActive(false);

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            playerNearby = true;

        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            playerNearby = false;
            // Se sair do range, garante que inventário fecha
            if (isOpen)
                CloseBau();

        }
    }
}
