﻿using UnityEngine;

public class LixoColetavel : MonoBehaviour
{
    public TipoLixo tipo;
    private bool jogadorPerto = false;
    private SpriteRenderer spriteRenderer;
    private Collider2D colisor;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        colisor = GetComponent<Collider2D>();
    }

    void Update()
    {
        if (jogadorPerto && Input.GetMouseButtonDown(0))
        {
            // Verifica se o clique foi em cima do lixo
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);

            RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);

            if (hit.collider != null && hit.collider == colisor)
            {
                SistemaDiaNoite diaNoite = SistemaDiaNoite.instancia;
                InventarioPlayer inventario = InventarioPlayer.instancia;

                if (diaNoite != null && diaNoite.ehDia)
                {
                    ColetarLixo();
                }
                else
                {
                    // Se tentar pegar à noite
                    if (diaNoite != null && !diaNoite.ehDia)
                        Debug.Log("Não é possível coletar lixo à noite!");
                }
            }
            
        }
    }

    private void ColetarLixo()
    {
        InventarioPlayer inventario = InventarioPlayer.instancia;
        if (inventario != null)
        {
            bool sucesso = inventario.AdicionarItem(this);
            if (sucesso)
            {
                gameObject.SetActive(false); // desativa lixo do chão
                Debug.Log("Lixo coletado: " + tipo);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = false;
        }
    }
}

