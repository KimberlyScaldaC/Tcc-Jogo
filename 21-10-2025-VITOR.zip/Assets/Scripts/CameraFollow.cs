using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public Transform target;   // Quem a c�mera vai seguir (seu personagem)
    public float smoothSpeed = 0.125f; // Velocidade da transi��o
    public Vector3 offset;     // Dist�ncia entre a c�mera e o personagem

    void LateUpdate()
    {
        if (target != null)
        {
            // Posi��o desejada da c�mera = posi��o do personagem + offset
            Vector3 desiredPosition = target.position + offset;

            // Faz a transi��o suave da c�mera at� o alvo
            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);

            // Aplica a posi��o
            transform.position = smoothedPosition;
        }
    }
}
