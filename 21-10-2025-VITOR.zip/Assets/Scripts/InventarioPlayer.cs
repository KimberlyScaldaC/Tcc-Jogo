﻿using System.Collections.Generic;
using UnityEngine;

public class InventarioPlayer : MonoBehaviour
{
    public static InventarioPlayer instancia;

    [Header("Slots")]
    public List<GameObject> slots = new List<GameObject>();
    public int slotsLiberados = 4;
    public int indiceSelecionado = 0;

    public LixoColetavel itemSelecionado;



    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    private void Start()
    {
        AtualizarItemSelecionado();
    }

    private void Update()
    {
        // Troca de item com scroll do mouse
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            slots[indiceSelecionado].GetComponent<Slot>().Destacar(false);
            if (scroll > 0)
                indiceSelecionado = (indiceSelecionado + 1) % slotsLiberados;
            else
                indiceSelecionado = (indiceSelecionado - 1 + slotsLiberados) % slotsLiberados;

            AtualizarItemSelecionado();
        }
    }

    public void AtualizarItemSelecionado()
    {

        Slot slotScript = slots[indiceSelecionado]?.GetComponent<Slot>();
        if (slotScript == null) return;

        itemSelecionado = slotScript.ObterItem();
        Debug.Log("itemSelecionado - "+ itemSelecionado);
        slotScript.Destacar(true);
    }

    public bool AdicionarItem(LixoColetavel item)
    {
        AtualizarItemSelecionado();
        for (int i = 0; i < slotsLiberados; i++)
        {
            AtualizarItemSelecionado();
            Slot slot = slots[i].GetComponent<Slot>();
            if (slot.ObterItem() == null)
            {
                slot.AdicionarItem(item);
                AtualizarItemSelecionado();
                itemSelecionado = item;
                Debug.Log("Item adicionado: " + item.tipo);
                return true;
            }
            
        }
        AtualizarItemSelecionado();


        Debug.Log("Inventário cheio!");
        return false;
    }

    public void RemoverItem(LixoColetavel item)
    {
        foreach (GameObject s in slots)
        {
            Slot slot = s.GetComponent<Slot>();
            if (slot.ObterItem() == item)
            {
                slot.RemoverItem();
                AtualizarItemSelecionado();
                if (itemSelecionado == item)
                    itemSelecionado = null;
                break;
            }
        }
    }
}
