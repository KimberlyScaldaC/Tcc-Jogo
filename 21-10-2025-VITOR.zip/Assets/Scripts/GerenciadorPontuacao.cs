using UnityEngine;
using UnityEngine.UI;

public class GerenciadorPontuacao : MonoBehaviour
{
    public static GerenciadorPontuacao instancia;
    public Text textoPontuacao;

    private int pontuacaoAtual = 0;

    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    public void AdicionarPontos(int valor)
    {
        pontuacaoAtual += valor;
        AtualizarUI();
    }

    private void AtualizarUI()
    {
        if (textoPontuacao != null)
            textoPontuacao.text = "Pontua��o: " + pontuacaoAtual;
    }

    public int GetPontuacao()
    {
        return pontuacaoAtual;
    }
}
