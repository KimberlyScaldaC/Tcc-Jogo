using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Configuracao : MonoBehaviour
{
    public GameObject configPanel;  // painel de configura��o
    public Button btnConfig;        // bot�o fixo no canto da tela
    public Button btnVoltar;        // bot�o Voltar
    public Button btnSomOn;         // bot�o Som On
    public Button btnSomOff;        // bot�o Som Off
    public Button btnSair;          // bot�o Sair

    void Start()
    {
        configPanel.SetActive(false); // esconde painel inicialmente

        btnConfig.onClick.AddListener(OpenConfig);
        btnVoltar.onClick.AddListener(CloseConfig);
        btnSomOn.onClick.AddListener(EnableSound);
        btnSomOff.onClick.AddListener(DisableSound);
        btnSair.onClick.AddListener(QuitGame);
    }

    void OpenConfig()
    {
        configPanel.SetActive(true);
        Time.timeScale = 0f; // pausa o jogo
    }

    void CloseConfig()
    {
        configPanel.SetActive(false);
        Time.timeScale = 1f; // volta o jogo
    }

    void EnableSound()
    {
        AudioListener.volume = 1f;
    }

    void DisableSound()
    {
        AudioListener.volume = 0f;
    }

    void QuitGame()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit();
    }
}

