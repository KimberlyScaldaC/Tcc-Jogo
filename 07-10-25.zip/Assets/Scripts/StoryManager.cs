﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class StoryManager : MonoBehaviour
{
    public float storyDuration = 5f; // tempo em segundos para a história

    void Start()
    {
        // Após storyDuration segundos, vai para a cena do jogo
        Invoke("StartGame", storyDuration);
        //SceneManager.LoadScene("Scenes/Jogo");
    }

    void StartGame()
    {
        SceneManager.LoadScene("Scenes/Jogo"); // nome da cena do jogo
    }

}
