﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class StoryDialogue : MonoBehaviour
{
    public TextMeshProUGUI dialogueText;  // Texto do balão
    public GameObject balloonImage;       // Imagem do balão
    public float dialogueSpeed = 0.05f;   // Velocidade do texto

    private string[] dialogues;           // Fal falas da cena
    private int index = 0;                // Índice da fala atual

    void Start()
    {
        balloonImage.SetActive(true);

        // Descobre qual cena está ativa
        string sceneName = SceneManager.GetActiveScene().name;

        if (sceneName == "LojaEletronicos") // nome exato da sua cena
        {
            dialogues = new string[]
            {
                "Bem-vindo à loja de eletrônicos!",
                "Aqui você pode recicla equipamentos eletronicos.",
            };
        }
        else if (sceneName == "Intro") // exemplo de outra cena
        {
            dialogues = new string[]
            {
                " ",
                "Oi! Acabei de me mudar para uma nova cidade.",
                "Comprei uma casa.",
                "Mas o quintal está cheio de lixo e entulho...",
                "Quero limpar tudo e reciclar o que for possível.",
                "Vamos nessa?"
            };
        }
        else
        {
            // Caso não esteja em nenhuma cena conhecida
            dialogues = new string[] { "Nenhum diálogo definido para esta cena." };
        }

        StartCoroutine(ShowDialogue());
    }

    IEnumerator ShowDialogue()
    {
        dialogueText.text = "";
        foreach (char c in dialogues[index])
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(dialogueSpeed);
        }
    }

    // Botão Next
    public void NextDialogue()
    {
        index++;
        if (index < dialogues.Length)
        {
            StopAllCoroutines();
            StartCoroutine(ShowDialogue());
        }
        else
        {
            // Fim do diálogo → ir para a cena do jogo
            SceneManager.LoadScene("Scenes/Jogo");
        }
    }

    // Botão Skip
    public void SkipStory()
    {
        SceneManager.LoadScene("Scenes/Jogo");
    }
}
