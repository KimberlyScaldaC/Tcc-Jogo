using UnityEngine;
using UnityEngine.UI;

public class Slot : MonoBehaviour
{
    public Image imagemSlot;
    public Image destaque; // contorno amarelo
    public Sprite spriteVazio;
    private LixoColetavel itemNoSlot; // refer�ncia l�gica do item


    public void AdicionarItem(LixoColetavel item)
    {
        itemNoSlot = item;
        if (itemNoSlot != null && imagemSlot != null)
        {
            imagemSlot.sprite = itemNoSlot.GetComponent<SpriteRenderer>().sprite;
            imagemSlot.enabled = true;
        }
        Destacar(false);
    }

    public void RemoverItem()
    {
        itemNoSlot = null;
        imagemSlot.sprite = spriteVazio; // volta para o visual de slot vazio
        imagemSlot.enabled = true; // mant�m o slot vis�vel
        Destacar(false);

    }

    public LixoColetavel ObterItem()
    {
        return itemNoSlot;
    }

    public void Destacar(bool valor)
    {
        if (destaque != null)
            destaque.enabled = valor;
    }
}
