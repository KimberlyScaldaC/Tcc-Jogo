﻿using UnityEngine;
using System.Collections;

public class LixoColetavel : MonoBehaviour
{
    public static LixoColetavel instancia;

    [Header("Configurações do Lixo")]
    public TipoLixo tipo;
    public string lixoID;

    [Header("Fumaça ao coletar")]
    public GameObject fumacaPrefab;
    public Vector3 offsetFumaca = new Vector3(0f, 0.2f, 0f);
    public float tempoFumaca = 0.8f;

    [Header("Configurações do Jogador")]
    private bool jogadorPerto = false;
    private SpriteRenderer spriteRenderer;
    private Collider2D colisor;

    

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        colisor = GetComponent<Collider2D>();
    }

    void Update()
    {
        if (jogadorPerto && Input.GetMouseButtonDown(0))
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);

            RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);

            if (hit.collider != null && hit.collider == colisor)
            {
                SistemaDiaNoite diaNoite = SistemaDiaNoite.instancia;
                InventarioPlayer inventario = InventarioPlayer.instancia;

                if (diaNoite != null && diaNoite.ehDia)
                {

                    
                    ColetarLixo();
                }
                else
                {
                    // Se tentar pegar à noite
                    if (diaNoite != null && !diaNoite.ehDia)
                        Debug.Log("Não é possível coletar lixo à noite!");
                }
            }
            
        }
    }

    public void ColetarLixo()
    {
        InventarioPlayer inventario = InventarioPlayer.instancia;
        if (inventario != null)
        {
            bool sucesso = inventario.AdicionarItem(this);
            if (sucesso)
            {
                gameObject.SetActive(false);
                if (fumacaPrefab != null)
                {
                    Vector3 posFumaca = transform.position + offsetFumaca;
                    GameObject f = Instantiate(fumacaPrefab, posFumaca, Quaternion.identity);
                    f.SetActive(true);
                    Destroy(f, tempoFumaca);
                }
                else
                {
                    Debug.LogWarning("[LixoColetavel] fumacaPrefab não atribuído no " + gameObject.name);
                }

                //gameObject.SetActive(false);
                //Debug.Log("Lixo coletado: " + tipo);

            }
            else
            {
                Debug.Log("Inventário cheio! Não é possível coletar mais lixo.");
            }
        }
    }


    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = false;
        }
    }
}

