using UnityEngine;
using TMPro;

public class ResultadosDia : MonoBehaviour
{
    public static ResultadosDia instancia;

    public GameObject painel;

    [Header("Textos - Lixos Reciclados")]
    public TextMeshProUGUI txtOrganico;
    public TextMeshProUGUI txtPlastico;
    public TextMeshProUGUI txtPapel;
    public TextMeshProUGUI txtVidro;
    public TextMeshProUGUI txtMetal;
    public TextMeshProUGUI txtEletronico;
    public TextMeshProUGUI txtMadeira;
    public TextMeshProUGUI txtPilha;

    [Header("Textos - Mat�ria Prima")]
    public TextMeshProUGUI txtMadeiraMP;
    public TextMeshProUGUI txtPlasticoMP;
    public TextMeshProUGUI txtPapelMP;
    public TextMeshProUGUI txtVidroMP;
    public TextMeshProUGUI txtMetalMP;
    public TextMeshProUGUI txtEletronicoMP;

    void Awake()
    {
        instancia = this;
        painel.SetActive(false);
    }

    public void MostrarResultados()
    {
        GameManager gm = GameManager.instancia;

        txtOrganico.text = "Org�nico: " + gm.recicladosOrganico;
        txtPlastico.text = "Pl�stico: " + gm.recicladosPlastico;
        txtPapel.text = "Papel: " + gm.recicladosPapel;
        txtVidro.text = "Vidro: " + gm.recicladosVidro;
        txtMetal.text = "Metal: " + gm.recicladosMetal;
        txtEletronico.text = "Eletr�nico: " + gm.recicladosEletronico;
        txtMadeira.text = "Madeira: " + gm.recicladosMadeira;
        txtPilha.text = "Pilha: " + gm.recicladosPilha;

        txtMadeiraMP.text = "Madeira: " + gm.madeira;
        txtPlasticoMP.text = "Pl�stico: " + gm.plastico;
        txtPapelMP.text = "Papel: " + gm.papel;
        txtVidroMP.text = "Vidro: " + gm.vidro;
        txtMetalMP.text = "Metal: " + gm.metal;
        txtEletronicoMP.text = "Eletr�nico: " + gm.eletronico;

        painel.SetActive(true);
        Time.timeScale = 0f;
    }

    public void FecharMenu()
    {
        painel.SetActive(false);
        Time.timeScale = 1f;
        GameManager.instancia.ResetarEstatisticasDia();
    }

    public void BotaoVoltarAoJogo()
    {
        painel.SetActive(false);        // fecha o menu
        Time.timeScale = 1f;            // despausa o jogo
        GameManager.instancia.ResetarEstatisticasDia(); // opcional: zera as estat�sticas di�rias
    }
}
