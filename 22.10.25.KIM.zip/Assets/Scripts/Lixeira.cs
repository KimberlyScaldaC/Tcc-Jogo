using UnityEngine;

public class Lixeira : MonoBehaviour
{

    public TipoLixo tipoAceito;

    [Header("Jogador")]
    private SpriteRenderer spriteRenderer;
    private Collider2D colisor;
    private bool jogadorPerto = false;

    [Header("Anima��o das lixeiras")]
    private Animator anim;


    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        colisor = GetComponent<Collider2D>();
        anim = GetComponent<Animator>();

    }

    void Update()
    {
        
        if (jogadorPerto && Input.GetKeyDown(KeyCode.E))
        {
            InventarioPlayer inventarioPlayer = InventarioPlayer.instancia;
            inventarioPlayer.AtualizarItemSelecionado();

            if (inventarioPlayer != null && inventarioPlayer.itemSelecionado != null)
            {
                LixoColetavel lixo = inventarioPlayer.itemSelecionado;
                
                if (lixo.tipo == tipoAceito)
                {
                    if (lixo.tipo != TipoLixo.Eletronico)
                        anim.SetTrigger("abrir");

                    if (lixo.tipo == TipoLixo.Eletronico)
                    {
                        

                        GameManager.instancia.lixoEletronicoNaCaixa = true;
                        GameManager.instancia.SalvarProgresso();
                        Debug.Log("Lixo eletr�nico colocado na caixa.");
                        lixo.gameObject.SetActive(false);

                        if (CaixaEletronicos.instancia != null)
                            CaixaEletronicos.instancia.EncherCaixa();
                    }

                    

                    int pontos = PontuacaoLixo.GetPontos(lixo.tipo);

                    Debug.Log("Lixo correto! - " + tipoAceito);
                    GameManager.instancia.RegistrarReciclagem(lixo.tipo);
                    inventarioPlayer.RemoverItem(lixo);
                    inventarioPlayer.AtualizarItemSelecionado();

                    GerenciadorPontuacao.instancia.AdicionarPontos(pontos);

                    if (BalaoMensagem.instancia != null)
                    {
                        BalaoMensagem.instancia.MostrarMensagem(
                            $"Lixo correto! +{pontos} pontos!");
                    }  
                }
                else
                {
                    Debug.Log("Lixo errado! Tempo reduzido.");
                    SistemaDiaNoite.instancia.IncrementarHora(10); // aumenta 10 minutos
                    if (BalaoMensagem.instancia != null)
                    {
                        BalaoMensagem.instancia.MostrarMensagem("Lixo no lugar errado!");
                    }

                }
            }
        }
    }

   
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = false;
        }
    }
}
