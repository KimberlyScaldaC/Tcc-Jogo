using UnityEngine;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager instancia;

    [Header("Caixa Eletr�nicos")]
    public bool lixoEletronicoNaCaixa = false;
    public bool historinhaMostrada = false;

    [Header("Progresso do jogador")]
    public int horaSalva;
    public int minutoSalvo;
    public int pontosTotal;

    [Header("Lixos reciclados por tipo")]
    public int recicladosOrganico;
    public int recicladosPlastico;
    public int recicladosPapel;
    public int recicladosVidro;
    public int recicladosMetal;
    public int recicladosEletronico;
    public int recicladosMadeira;
    public int recicladosPilha;

    [Header("Mat�ria-prima obtida")]
    public int madeira;
    public int plastico;
    public int papel;
    public int vidro;
    public int metal;
    public int eletronico;

    void Start()
    {
        lixoEletronicoNaCaixa = false;
        historinhaMostrada = false;
    }

    private void Awake()
    {
        if (instancia == null)
        {
            instancia = this;
            DontDestroyOnLoad(gameObject);

            // Carregar progresso salvo
            lixoEletronicoNaCaixa = PlayerPrefs.GetInt("lixoEletronicoNaCaixa", 0) == 1;
            historinhaMostrada = PlayerPrefs.GetInt("historinhaMostrada", 0) == 1;

            horaSalva = PlayerPrefs.GetInt("horaSalva", 6);
            minutoSalvo = PlayerPrefs.GetInt("minutoSalvo", 0);
            pontosTotal = PlayerPrefs.GetInt("pontosTotal", 0);
        }
        else
        {
            Destroy(gameObject);
        }
    }


    public void SalvarHorario(int hora, int minuto, int pontos)
    {
        horaSalva = hora;
        minutoSalvo = minuto;
        pontosTotal = pontos;
        PlayerPrefs.SetInt("horaSalva", hora);
        PlayerPrefs.SetInt("minutoSalvo", minuto);
        PlayerPrefs.SetInt("pontosTotal", pontos);
        PlayerPrefs.Save();
    }

    public void CarregarHorario(out int hora, out int minuto)
    {
        hora = PlayerPrefs.GetInt("horaSalva", 6);
        minuto = PlayerPrefs.GetInt("minutoSalvo", 0);
    }

    public void SalvarProgresso()
    {
        PlayerPrefs.SetInt("lixoEletronicoNaCaixa", lixoEletronicoNaCaixa ? 1 : 0);
        PlayerPrefs.SetInt("historinhaMostrada", historinhaMostrada ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void RegistrarReciclagem(TipoLixo tipo)
    {
        switch (tipo)
        {
            case TipoLixo.Organico:
                recicladosOrganico++;
                break;

            case TipoLixo.Plastico:
                recicladosPlastico++;
                plastico += 2;
                break;

            case TipoLixo.Papel:
                recicladosPapel++;
                papel += 2;
                break;

            case TipoLixo.Vidro:
                recicladosVidro++;
                vidro += 3;
                break;

            case TipoLixo.Metal:
                recicladosMetal++;
                metal += 4;
                break;

            case TipoLixo.Eletronico:
                recicladosEletronico++;
                eletronico += 5;
                break;

            case TipoLixo.Madeira:
                recicladosMadeira++;
                madeira += 2;
                break;
                
            case TipoLixo.Pilha:
                recicladosPilha++;
                break;
        }
    }

    public void ResetarEstatisticasDia()
    {
        recicladosOrganico = 0;
        recicladosPlastico = 0;
        recicladosPapel = 0;
        recicladosVidro = 0;
        recicladosMetal = 0;
        recicladosEletronico = 0;
        recicladosMadeira = 0;
        recicladosPilha = 0;

        madeira = 0;
        plastico = 0;
        papel = 0;
        vidro = 0;
        metal = 0;
        eletronico = 0;
    }

}
