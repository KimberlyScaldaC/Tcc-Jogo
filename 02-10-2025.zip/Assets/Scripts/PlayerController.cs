using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 3f; // Velocidade do personagem
    private Rigidbody2D rb; // Refer�ncia ao corpo f�sico 2D do personagem
    private SpriteRenderer spriteRenderer; // Refer�ncia ao SpriteRenderer (pra virar o boneco)
    private Animator animator; // <-- NOVO: Refer�ncia ao Animator

    // Start is called before the first frame update
    void Start()
    {

        // Pega os componentes do personagem assim que o jogo come�a
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        
    }

    // Update is called once per frame
    void Update()
    {
        // L� o movimento horizontal (teclas A/D ou setas ? ?)
        // Retorna -1 (esquerda), 0 (parado) ou 1 (direita)
        float horizontal = Input.GetAxis("Horizontal");


        // Define a velocidade do personagem no eixo X
        // Mantendo a velocidade atual no eixo Y (pra n�o mexer no pulo ou gravidade)
        rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);

        if (rb.velocity != Vector2.zero)
        {
            animator.SetBool("parado",false );
            // Virar sprite para o lado que anda
            if (horizontal > 0)
                spriteRenderer.flipX = false; // olhando para direita
            else if (horizontal < 0)
                spriteRenderer.flipX = true; // olhando para esquerda
        }
        else
        {
            animator.SetBool("parado", true);
        }


    }
}
