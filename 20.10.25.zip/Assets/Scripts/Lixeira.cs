using UnityEngine;

public class Lixeira : MonoBehaviour
{
    public TipoLixo tipoAceito;
    private SpriteRenderer spriteRenderer;
    private Collider2D colisor;
    private bool jogadorPerto = false;
   

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        colisor = GetComponent<Collider2D>();
    }

    void Update()
    {
        
        if (jogadorPerto && Input.GetKeyDown(KeyCode.E))
        {
            InventarioPlayer inventarioPlayer = InventarioPlayer.instancia;
            inventarioPlayer.AtualizarItemSelecionado();

            if (inventarioPlayer != null && inventarioPlayer.itemSelecionado != null)
            {
                LixoColetavel lixo = inventarioPlayer.itemSelecionado;
                Debug.Log("------------------ + ----------------- ");
                Debug.Log("lixo.tipo - " + lixo.tipo);
                Debug.Log("tipoAceito - " + tipoAceito);
                Debug.Log("------------------ + ----------------- ");
                
                if (lixo.tipo == tipoAceito)
                {
                    Debug.Log("Lixo correto! - "+ tipoAceito);
                    inventarioPlayer.RemoverItem(lixo);
                    inventarioPlayer.AtualizarItemSelecionado();
                    
                    
                }
                else
                {
                    Debug.Log("Lixo errado! Tempo reduzido.");
                    SistemaDiaNoite.instancia.IncrementarHora(10); // aumenta 10 minutos
                    if (BalaoMensagem.instancia != null)
                    {
                        BalaoMensagem.instancia.MostrarMensagem("Lixo no lugar errado!");
                    }

                }
            }
        }
    }

   
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = false;
        }
    }
}
