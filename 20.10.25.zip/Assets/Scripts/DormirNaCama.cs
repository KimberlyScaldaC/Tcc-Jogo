using UnityEngine;

public class DormirNaCama : MonoBehaviour
{
    private bool jogadorPerto = false;

    private void Update()
    {
        if (jogadorPerto && Input.GetKeyDown(KeyCode.E))
        {
            SistemaDiaNoite sistema = SistemaDiaNoite.instancia;
            if (sistema != null)
                sistema.Dormir();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
            jogadorPerto = true;
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
            jogadorPerto = false;
    }
}
