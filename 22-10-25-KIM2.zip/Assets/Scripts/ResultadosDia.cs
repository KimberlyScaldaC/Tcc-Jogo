using UnityEngine;
using TMPro;

public class ResultadosDia : MonoBehaviour
{
    public static ResultadosDia instancia;

    public GameObject painel;

    [Header("UI do jogo")]
    public GameObject inventarioHUD;
    public GameObject balao;

    [Header("Textos - Pontua�ao - Lixos Reciclados")]
    public TextMeshProUGUI txtOrganico;
    public TextMeshProUGUI txtPlastico;
    public TextMeshProUGUI txtPapel;
    public TextMeshProUGUI txtVidro;
    public TextMeshProUGUI txtMetal;
    public TextMeshProUGUI txtEletronico;
    public TextMeshProUGUI txtMadeira;
    public TextMeshProUGUI txtPilha;

    [Header("Textos - Quantidade - Lixos Reciclados")]
    public TextMeshProUGUI txtOrganicoQuant;
    public TextMeshProUGUI txtPlasticoQuant;
    public TextMeshProUGUI txtPapelQuant;
    public TextMeshProUGUI txtVidroQuant;
    public TextMeshProUGUI txtMetalQuant;
    public TextMeshProUGUI txtEletronicoQuant;
    public TextMeshProUGUI txtMadeiraQuant;
    public TextMeshProUGUI txtPilhaQuant;

    [Header("Textos - Mat�ria Prima")]
    public TextMeshProUGUI txtMadeiraMP;
    public TextMeshProUGUI txtPlasticoMP;
    public TextMeshProUGUI txtPapelMP;
    public TextMeshProUGUI txtVidroMP;
    public TextMeshProUGUI txtMetalMP;
    public TextMeshProUGUI txtEletronicoMP;

    void Awake()
    {
        instancia = this;
        painel.SetActive(false);
    }

    public void MostrarResultados()
    {
        // Desabilita o invent�rio/HUD
        if (inventarioHUD != null)
        {
            inventarioHUD.SetActive(false);
            balao.SetActive(false);
        }

        GameManager gm = GameManager.instancia;

        txtOrganicoQuant.text = "" + gm.recicladosOrganicoQuant;
        txtPlasticoQuant.text = "" + gm.recicladosPlasticoQuant;
        txtPapelQuant.text = "" + gm.recicladosPapelQuant;
        txtVidroQuant.text = "" + gm.recicladosVidroQuant;
        txtMetalQuant.text = "" + gm.recicladosMetalQuant;
        txtEletronicoQuant.text = "" + gm.recicladosEletronicoQuant;
        txtMadeiraQuant.text = "" + gm.recicladosMadeiraQuant;
        txtPilhaQuant.text = "" + gm.recicladosPilhaQuant;

        txtOrganico.text = "" + gm.recicladosOrganico;
        txtPlastico.text = "" + gm.recicladosPlastico;
        txtPapel.text = "" + gm.recicladosPapel;
        txtVidro.text = "" + gm.recicladosVidro;
        txtMetal.text = "" + gm.recicladosMetal;
        txtEletronico.text = "" + gm.recicladosEletronico;
        txtMadeira.text = "" + gm.recicladosMadeira;
        txtPilha.text = "" + gm.recicladosPilha;

        txtMadeiraMP.text = "" + gm.madeira;
        txtPlasticoMP.text = "" + gm.plastico;
        txtPapelMP.text = "" + gm.papel;
        txtVidroMP.text = "" + gm.vidro;
        txtMetalMP.text = "" + gm.metal;
        txtEletronicoMP.text = "" + gm.eletronico;

        painel.SetActive(true);
        Time.timeScale = 0f;
    }

    public void FecharMenu()
    {
        painel.SetActive(false);
        Time.timeScale = 1f;
        GameManager.instancia.ResetarEstatisticasDia();
    }

    public void BotaoVoltarAoJogo()
    {
        if (inventarioHUD != null)
        {
            inventarioHUD.SetActive(true);
            balao.SetActive(true);
        }
        painel.SetActive(false);        // fecha o menu
        Time.timeScale = 1f;            // despausa o jogo
        GameManager.instancia.ResetarEstatisticasDia(); // opcional: zera as estat�sticas di�rias
    }
}
