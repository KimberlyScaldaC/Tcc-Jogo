using UnityEngine;

public class BoxController : MonoBehaviour
{
    public Animator animator;           // Animator do ba�
    public GameObject inventarioBau;    // Painel de invent�rio
 

    private bool isOpen = false;
    private bool playerNearby = false;

    private void Start()
    {
        inventarioBau.SetActive(false);
    }

    void Update()
    {
        if (playerNearby)
        {
            // Abrir ba�
            if (Input.GetKeyDown(KeyCode.E) && !isOpen)
            {
                OpenBau();
            }

            // Fechar ba�
            if (Input.GetKeyDown(KeyCode.X) && isOpen)
            {
                CloseBau();
            }
        }
    }

    void OpenBau()
    {
        isOpen = true;
        animator.SetBool("isOpen", true);   // ativa anima��o
        inventarioBau.SetActive(true);     // mostra invent�rio

    }

    void CloseBau()
    {
        isOpen = false;
        animator.SetBool("isOpen", false);  // ativa anima��o de fechar
        inventarioBau.SetActive(false);    // esconde invent�rio

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            playerNearby = true;

        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            playerNearby = false;
            // Se sair do range, garante que invent�rio fecha
            if (isOpen)
                CloseBau();

        }
    }
}
