using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Teleporte : MonoBehaviour
{
    public Transform pontoDestino; // Para onde o jogador vai ser teleportado
    private bool jogadorPerto = false;

    void Update()
    {
        if (jogadorPerto && Input.GetKeyDown(KeyCode.E))
        {
            Teleportar();
        }
    }

    private void Teleportar()
    {
        GameObject jogador = GameObject.FindGameObjectWithTag("Personagem"); // assume que o jogador tem tag "Player"
        if (jogador != null && pontoDestino != null)
        {
            jogador.transform.position = pontoDestino.position;
            Debug.Log("Jogador teleportado!");
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = true;
            Debug.Log("Jogador pode teletransportar.");
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = false;
            Debug.Log("Jogador saiu da �rea de teleporte.");
        }
    }
}
