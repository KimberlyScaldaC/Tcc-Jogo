using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class InventarioBau : MonoBehaviour
{
    public GameObject inventarioUI;

    // Abre o invent�rio
    public void Abrir()
    {
        inventarioUI.SetActive(true);
    }

    // Fecha o invent�rio
    public void Fechar()
    {
        inventarioUI.SetActive(false);
    }
}
