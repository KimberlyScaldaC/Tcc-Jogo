﻿using UnityEngine;
using UnityEngine.UI;


//ESTA FUNCIONANDO


public class HotbarController : MonoBehaviour
{
    public Image[] slotImages;
    private int selectedSlot = 0;

    void Start()
    {
        UpdateHotbarUI();
    }

    void Update()
    {
        HandleInput();
    }

    void HandleInput()
    {
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll > 0f)
        {
            selectedSlot = (selectedSlot + 1) % slotImages.Length;
            UpdateHotbarUI();
        }
        else if (scroll < 0f)
        {
            selectedSlot--;
            if (selectedSlot < 0) selectedSlot = slotImages.Length - 1;
            UpdateHotbarUI();
        }

        if (Input.GetKeyDown(KeyCode.Alpha1)) { selectedSlot = 0; UpdateHotbarUI(); }
        if (Input.GetKeyDown(KeyCode.Alpha2)) { selectedSlot = 1; UpdateHotbarUI(); }
        if (Input.GetKeyDown(KeyCode.Alpha3)) { selectedSlot = 2; UpdateHotbarUI(); }
        if (Input.GetKeyDown(KeyCode.Alpha4)) { selectedSlot = 3; UpdateHotbarUI(); }
    }

    void UpdateHotbarUI()
    {
        for (int i = 0; i < slotImages.Length; i++)
        {
            Color highlightColor = new Color(1f, 1f, 0f, 180f/255f);
            Color emptyColor     = new Color(1f, 1f, 1f, 180f/255f);
            slotImages[i].color = (i == selectedSlot) ? highlightColor : emptyColor;
        }
    }

}
