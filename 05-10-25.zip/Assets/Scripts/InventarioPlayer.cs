using UnityEngine;
using System.Collections.Generic;

public class InventarioPlayer : MonoBehaviour
{
    public static InventarioPlayer instancia; // Singleton
    public List<GameObject> slots = new List<GameObject>();
    public int slotsLiberados = 4;

    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    public bool AdicionarItem(GameObject item)
    {
        for (int i = 0; i < slotsLiberados; i++)
        {
            Slot slot = slots[i].GetComponent<Slot>();
            if (slot.itemAtual == null)
            {
                slot.AdicionarItem(item);
                Debug.Log("Item adicionado no slot " + (i + 1));
                return true;
            }
        }

        Debug.Log("Invent�rio cheio nos slots liberados!");
        return false; // n�o conseguiu adicionar
    }
}
