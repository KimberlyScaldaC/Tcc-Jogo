using UnityEngine;

public class LixoColetavel : MonoBehaviour
{
    private bool jogadorPerto = false;
    private SpriteRenderer spriteRenderer;
    private Collider2D colisor;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        colisor = GetComponent<Collider2D>();
    }

    void Update()
    {
        // Se o jogador estiver perto e clicar com o mouse
        if (jogadorPerto && Input.GetMouseButtonDown(0))
        {
            // Verifica se o clique foi em cima do lixo
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);

            RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);

            if (hit.collider != null && hit.collider == colisor)
            {
                ColetarLixo();
            }
        }
    }

    private void ColetarLixo()
    {
        InventarioPlayer inventario = InventarioPlayer.instancia;

        if (inventario != null)
        {
            bool conseguiuAdicionar = inventario.AdicionarItem(gameObject);
            if (conseguiuAdicionar)
            {
                gameObject.SetActive(false); // remove o lixo do ch�o
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = true;
            Debug.Log("Jogador est� perto do lixo.");
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            jogadorPerto = false;
            Debug.Log("Jogador saiu de perto do lixo.");
        }
    }
}
