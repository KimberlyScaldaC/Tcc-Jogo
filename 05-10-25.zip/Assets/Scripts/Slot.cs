using UnityEngine;
using UnityEngine.UI;

public class Slot : MonoBehaviour
{
    public Image imagemSlot;
    public GameObject itemAtual;

    public void AdicionarItem(GameObject item)
    {
        itemAtual = item;
        imagemSlot.sprite = item.GetComponent<SpriteRenderer>().sprite;
        imagemSlot.enabled = true;
    }

    public void LimparSlot()
    {
        itemAtual = null;
        imagemSlot.sprite = null;
        imagemSlot.enabled = false;
    }
}
