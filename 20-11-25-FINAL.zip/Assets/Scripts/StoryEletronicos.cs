﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class StoryEletronicos : MonoBehaviour
{
    public TextMeshProUGUI dialogueText;  // Texto do balão
    public GameObject balloonImage;       // Imagem do balão
    public float dialogueSpeed = 0.05f;   // Velocidade do texto

    private string[] dialogues;           // Fal falas da cena
    private int index = 0;                // Índice da fala atual

    private bool isTyping = false;
    private string currentLine = "";


    void Awake()
    {
        // segurança: caso alguém esqueça de atribuir no Inspector
        if (dialogueText == null)
            Debug.LogError("StoryDialogue: dialogueText NÃO está atribuído no Inspector.");

        if (balloonImage == null)
            Debug.LogError("StoryDialogue: balloonImage NÃO está atribuído no Inspector.");
    

    }

    void Start()
    {

        balloonImage.SetActive(true);

        // Cena atual
        string sceneName = SceneManager.GetActiveScene().name;

        if (sceneName == "LojaEletronicos")
        {
            dialogues = new string[]
            {
                "Bem-vindo à loja de eletrônicos!",
                "Aqui você pode reciclar equipamentos eletrônicos."
            };
        }
        else
        {
            dialogues = new string[] { "Nenhum diálogo definido para esta cena." };
        }
        StartCoroutine(ShowDialogue());
    }


    IEnumerator ShowDialogue()
    {
        Debug.Log("ShowDialogue");
        isTyping = true;


        
        dialogueText.text = "";
        foreach (char c in dialogues[index])
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(dialogueSpeed);
        }

        isTyping = false;
    }

    public void NextDialogue()
    {
        Debug.Log("NextDialogue");
        /// SE TIVER DIGITANDO → COMPLETA IMEDIATO
        if (isTyping)
        {
            dialogueText.text = currentLine;
            isTyping = false;
            return;
        }
        currentLine = dialogues[index];
        index++;

        if (index < dialogues.Length)
        {
            StartCoroutine(ShowDialogue());
        }
        else
        {
            EndStory();
        }
    }

    public void SkipStory()
    {
        EndStory();
    }

    void EndStory()
    {
        Teste.instancia.Historinha();

        // Agora sem o erro — usa o nome CERTO da cena
        if (SceneManager.GetSceneByName("LojaEletronicos").isLoaded)
            SceneManager.UnloadSceneAsync("LojaEletronicos");

        
    }
}
