﻿using System.Collections.Generic;

public static class PontuacaoLixo
{
    // Dicionário: TipoLixo → Pontos base
    private static readonly Dictionary<TipoLixo, int> pontuacaoBase = new Dictionary<TipoLixo, int>
    {
        { TipoLixo.Papel, 30 },
        { TipoLixo.Plastico, 60 },
        { TipoLixo.Vidro, 40 },
        { TipoLixo.Metal, 100 },
        { TipoLixo.Madeira, 50 },
        { TipoLixo.Organico, 20 },
        { TipoLixo.Pilha, 80 },
        { TipoLixo.Eletronico, 100 }
    };

    public static int GetPontos(TipoLixo tipo)
    {
        if (pontuacaoBase.ContainsKey(tipo))
            return pontuacaoBase[tipo];
        return 0;
    }
}
