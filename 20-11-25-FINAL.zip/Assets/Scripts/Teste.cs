using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Teste : MonoBehaviour
{
    public static Teste instancia;

    // Start is called before the first frame update
    void Start()
    {
        if (instancia == null)
        {
            instancia = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Historinha()
    {

        GameManager.instancia.historinhaMostrada = true;
        //SistemaDiaNoite.instancia.carregandoCena = false;
    }


}
