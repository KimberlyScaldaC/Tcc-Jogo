﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventarioPlayer : MonoBehaviour
{
    public static InventarioPlayer instancia;

    [Header("Configuração do inventário")]
    public List<GameObject> slots = new List<GameObject>();
    public Image[] slotImages;
    public int slotsLiberados = 4;
    public int indiceSelecionado = 0;

    public LixoColetavel itemSelecionado;

    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    private void Start()
    {
        AtualizarItemSelecionado();
    }

    private void Update()
    {
        // Troca de item com scroll do mouse
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            slots[indiceSelecionado].GetComponent<Slot>().Destacar(false);
            if (scroll > 0)
            {
                indiceSelecionado = (indiceSelecionado + 1) % slotsLiberados;
                
                UpdateHotbarUI();
            }else
            {
                indiceSelecionado = (indiceSelecionado - 1 + slotsLiberados) % slotsLiberados;
                UpdateHotbarUI();
            }
            

            AtualizarItemSelecionado();
        }
    }

    public void AtualizarItemSelecionado()
    {

        Slot slotScript = slots[indiceSelecionado]?.GetComponent<Slot>();
        if (slotScript == null) return;

        itemSelecionado = slotScript.ObterItem();
        //Debug.Log("itemSelecionado - "+ itemSelecionado);
        slotScript.Destacar(true);
    }

    void UpdateHotbarUI()
    {
        for (int i = 0; i<slotImages.Length; i++)
        {
            Color highlightColor = new Color(1f, 1f, 0f, 180f / 255f);
            Color emptyColor = new Color(1f, 1f, 1f, 180f / 255f);
            slotImages[i].color = (i == indiceSelecionado) ? highlightColor : emptyColor;
        }
    }
    public bool AdicionarItem(LixoColetavel item)
    {
        AtualizarItemSelecionado();
        for (int i = 0; i < slotsLiberados; i++)
        {
            AtualizarItemSelecionado();
            Slot slot = slots[i].GetComponent<Slot>();
            if (slot.ObterItem() == null)
            {
                slot.AdicionarItem(item);
                AtualizarItemSelecionado();
                itemSelecionado = item;
                //Debug.Log("Item adicionado: " + item.tipo);
                return true;
            }
            
        }
        AtualizarItemSelecionado();


        Debug.Log("Inventário cheio!");
        return false;
    }

    public void RemoverItem(LixoColetavel item)
    {
        foreach (GameObject s in slots)
        {
            Slot slot = s.GetComponent<Slot>();
            if (slot.ObterItem() == item)
            {
                slot.RemoverItem();
                AtualizarItemSelecionado();
                if (itemSelecionado == item)
                    itemSelecionado = null;
                break;
            }
        }
    }

    public void AdicionarSlots(int quantidade)
    {
        Debug.Log("ADICIONA SLOT");
        slotsLiberados += quantidade;
        if (slotsLiberados > slots.Count)
            slotsLiberados = slots.Count;

        AtualizarSlots();
    }

    private void AtualizarSlots()
    {
        for (int i = 0; i < slots.Count; i++)
        {
            if (i < slotsLiberados)
                slots[i].SetActive(true);
            else
                slots[i].SetActive(false);
        }
    }
}
