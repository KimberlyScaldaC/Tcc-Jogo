using UnityEngine;

public class MesaDeTrabalho : MonoBehaviour
{
    public static MesaDeTrabalho instancia;

    [Header("Refer�ncia ao objeto MESA em si")]
    public GameObject mesa;   // <<< A MESA f�sica no cen�rio

    [Header("Painel da loja da mesa")]
    public GameObject painelLoja;

    [Header("Balao/Intera��o")]
    public GameObject balao;

    [Header("Status da compra")]
    public bool mesaComprada = false;

    private bool jogadorPerto = false;

    private void Awake()
    {
        instancia = this;
    }

    void Start()
    {
        // Mesa s� aparece se foi comprada
        AtualizarVisibilidade();

        // Painel come�a fechado
        if (painelLoja != null)
            painelLoja.SetActive(false);
    }

    void Update()
    {
        if (!jogadorPerto) return;

        // Abrir loja (somente se a mesa for comprada!)
        if (Input.GetKeyDown(KeyCode.E))
            OpenMenuLoja();

        // Fechar loja
        if (Input.GetKeyDown(KeyCode.X))
            CloseMenuLoja();
    }

    // CHAMADO PELO SCRIPT DA LOJA QUANDO O JOGADOR COMPRA A MESA
    public void ComprarMesa()
    {
        mesaComprada = true;
        AtualizarVisibilidade();
    }

    public void AtualizarVisibilidade()
    {
        if (mesa != null)
            mesa.SetActive(mesaComprada);
    }

    public void OpenMenuLoja()
    {
        if (!mesaComprada) return;

        balao.SetActive(false);
        painelLoja.SetActive(true);
    }

    public void CloseMenuLoja()
    {
        painelLoja.SetActive(false);
        balao.SetActive(true);
    }

    void OnTriggerEnter2D(Collider2D outro)
    {
        if (outro.CompareTag("Personagem"))
        {
            jogadorPerto = true;
            if (mesaComprada)
                balao.SetActive(true);
        }
    }

    void OnTriggerExit2D(Collider2D outro)
    {
        if (outro.CompareTag("Personagem"))
        {
            jogadorPerto = false;

            if (painelLoja != null)
                painelLoja.SetActive(false);

            balao.SetActive(false);
        }
    }
}
