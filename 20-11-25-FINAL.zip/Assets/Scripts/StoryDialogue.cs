﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class StoryDialogue : MonoBehaviour
{
    public TextMeshProUGUI dialogueText;  // Texto do balão
    public GameObject balloonImage;       // Imagem do balão
    public float dialogueSpeed = 0.05f;   // Velocidade do texto

    private string[] dialogues;           // Fal falas da cena
    private int index = 0;                // Índice da fala atual
    private int num = 0;

    private bool isTyping = false;
    private string currentLine = "";

    void Start()
    {
        balloonImage.SetActive(true);

        // Descobre qual cena está ativa
        string sceneName = SceneManager.GetActiveScene().name;

        if (sceneName == "LojaEletronicos") // nome exato da sua cena
        {
            dialogues = new string[]
            {
                "Bem-vindo à loja de eletrônicos!",
                "Aqui você pode recicla equipamentos eletronicos.",
            };
        }
        else if (sceneName == "Intro") // exemplo de outra cena
        {
            dialogues = new string[]
            {
                " ",
                "Oi! Acabei de me mudar para uma nova cidade.",
                "Comprei uma casa.",
                "Mas o quintal está cheio de lixo e entulho...",
                "Quero limpar tudo e reciclar o que for possível.",
                "Vamos nessa?"
            };
        }
        else
        {
            // Caso não esteja em nenhuma cena conhecida
            dialogues = new string[] { "Nenhum diálogo definido para esta cena." };
        }

        StartTyping();   // <--- VOCÊ NÃO TINHA ISSO!
    }

    void StartTyping()
    {
        StopAllCoroutines();
        currentLine = dialogues[index];
        StartCoroutine(TypeSentence(currentLine));   // <--- ESSA LINHA É ESSENCIAL
    }

    IEnumerator TypeSentence(string line)
    {
        isTyping = true;
        dialogueText.text = "";

        foreach (char c in line)
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(dialogueSpeed);
        }

        isTyping = false;
    }

    public void NextDialogue()
    {
        Debug.Log("NextDialogue");

        // Se estiver digitando → completa a frase
        if (isTyping)
        {
            StopAllCoroutines();
            dialogueText.text = currentLine;
            isTyping = false;
            return;
        }

        // Avança
        index++;

        if (index < dialogues.Length)
        {
            StartTyping(); // <--- AQUI CHAMA A DIGITAÇÃO DE NOVO
        }
        else
        {
            EndStory();
        }
    }



    void EndStory()
    {
        Teste.instancia.Historinha();

        // Agora sem o erro — usa o nome CERTO da cena
        if (SceneManager.GetSceneByName("LojaEletronicos").isLoaded)
            SceneManager.UnloadSceneAsync("LojaEletronicos");


    }



    public void SkipStory()
    {
        EndStory();
    }

    IEnumerator ShowDialogue()
    {
        Debug.Log("ShowDialogue");
        isTyping = true;

        dialogueText.text = "";
        foreach (char c in dialogues[index])
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(dialogueSpeed);
        }

        isTyping = false;
    }

    public void NextDialogueIntro()
    {
        index++;
        if (index < dialogues.Length)
        {
            StopAllCoroutines();
            StartCoroutine(ShowDialogue());
        }
        else
        {
            // Fim do diálogo → ir para a cena do jogo
            SceneManager.LoadScene("Scenes/Jogo");
        }
    }


    public void SkipStoryIntro()
    {
        SceneManager.LoadScene("Scenes/Jogo");
    }
}
