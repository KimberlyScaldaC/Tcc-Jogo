﻿using UnityEngine;

public class Configuracao : MonoBehaviour
{
    [Header("Painel do menu")]
    public GameObject configPanel; // painel de pausa

    [Header("Painel de Controles")]
    public GameObject controlesPanel; // <<< painel onde ficam os controles

    [Header("Música")]
    public AudioSource musica;

    [Header("UI do jogo")]
    public GameObject balao;

    void Start()
    {
        if (configPanel != null)
            configPanel.SetActive(false);

        if (controlesPanel != null)
            controlesPanel.SetActive(false);
    }

    // Alterna o menu aberto/fechado
    public void ToggleMenu()
    {
        if (configPanel == null) return;

        balao.SetActive(false);

        bool menuAberto = !configPanel.activeSelf;
        configPanel.SetActive(menuAberto);

        // Tempo pausa
        Time.timeScale = menuAberto ? 0f : 1f;
    }

    // Fecha apenas o menu principal
    public void FecharMenu()
    {
        balao.SetActive(true);
        if (configPanel == null) return;

        configPanel.SetActive(false);
        Time.timeScale = 1f;
    }

    // 🔹 ABRIR PAINEL DE CONTROLES
    public void AbrirControles()
    {
        configPanel.SetActive(false);     // fecha o pause menu
        controlesPanel.SetActive(true);   // abre controles
    }

    // 🔹 VOLTAR DO PAINEL DE CONTROLES PARA O PAUSE MENU
    public void VoltarParaMenu()
    {
        controlesPanel.SetActive(false);
        configPanel.SetActive(true);
    }

    // Liga a música
    public void LigarSom()
    {
        AudioListener.volume = 1f;
        if (musica != null && !musica.isPlaying)
            musica.Play();
    }

    // Desliga a música
    public void DesligarSom()
    {
        AudioListener.volume = 0f;
        if (musica != null)
            musica.Pause();
    }

    // Sair do jogo
    public void SairDoJogo()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit();
    }
}
