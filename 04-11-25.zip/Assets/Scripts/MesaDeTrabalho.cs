using UnityEngine;

public class MesaDeTrabalho : MonoBehaviour
{
    [Header("Refer�ncia ao painel da loja")]
    public GameObject painelLoja;

    private bool jogadorPerto = false;

    void Start()
    {
        if (painelLoja != null)
            painelLoja.SetActive(false);
    }

    void Update()
    {
        // Verifica se o jogador est� pr�ximo e pressiona E
        if (jogadorPerto && Input.GetKeyDown(KeyCode.E))
        {
            if (painelLoja != null)
            {
                bool ativo = painelLoja.activeSelf;
                painelLoja.SetActive(!ativo); // alterna abrir/fechar
            }
        }
    }

    void OnTriggerEnter2D(Collider2D outro)
    {
        if (outro.CompareTag("Personagem"))
            jogadorPerto = true;
    }

    void OnTriggerExit2D(Collider2D outro)
    {
        if (outro.CompareTag("Personagem"))
        {
            jogadorPerto = false;
            if (painelLoja != null)
                painelLoja.SetActive(false); // fecha ao sair
        }
    }
}
