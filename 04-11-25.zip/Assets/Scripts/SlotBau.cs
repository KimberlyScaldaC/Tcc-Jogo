using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SlotBau : MonoBehaviour
{
    public static SlotBau instancia;

    [Header("UI do Slot")]
    public Image imagemItem;
    public TextMeshProUGUI txtNome;
    public TextMeshProUGUI txtQuantidade;

    [Header("Mat�ria-prima obtida")]
    public int madeira;
    public int plastico;
    public int papel;
    public int vidro;
    public int metal;
    public int eletronico;

    private void Awake()
    {
        if (instancia == null) instancia = this;
    }

    public void AtualizarSlot(Sprite sprite, string nome, int quantidade)
    {
        if (imagemItem == null || txtNome == null || txtQuantidade == null) return;

        if (sprite != null)
        {
            imagemItem.sprite = sprite;
            imagemItem.enabled = true;
        }
        else
        {
            imagemItem.enabled = false;
        }

        switch(nome)
        {
            case "Madeira":
                madeira += quantidade;
                txtQuantidade.text = madeira.ToString();
                break;
            case "Pl�stico":
                plastico += quantidade;
                txtQuantidade.text = plastico.ToString();
                break;
            case "Papel":
                papel += quantidade;
                txtQuantidade.text = papel.ToString();
                break;
            case "Vidro":
                vidro += quantidade;
                txtQuantidade.text = vidro.ToString();
                break;
            case "Metal":
                metal += quantidade;
                txtQuantidade.text = metal.ToString();
                break;
            case "Eletr�nico":
                eletronico += quantidade;
                txtQuantidade.text = eletronico.ToString();
                break;
        }

        txtNome.text = nome;
         
    }

    public int GetQuantidadeMateria(string nome)
    {
        return nome switch
        {
            "Madeira" => madeira,
            "Plastico" => plastico,
            "Papel" => papel,
            "Vidro" => vidro,
            "Metal" => metal,
            "Eletr�nico" => eletronico,
            _ => 0
        };
    }

    public void ConsumirMateria(string nome, int qtd)
    {
        switch (nome)
        {
            case "Madeira": madeira -= qtd; break;
            case "Plastico": plastico -= qtd; break;
            case "Papel": papel -= qtd; break;
            case "Vidro": vidro -= qtd; break;
            case "Metal": metal -= qtd; break;
            case "Eletr�nico": eletronico -= qtd; break;
        }
    }
}