using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GerenciadorPontuacao : MonoBehaviour
{
    public static GerenciadorPontuacao instancia;
    public TextMeshProUGUI textoPontuacao;

    private int pontuacaoAtual = 0;

    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    public void AdicionarPontos(int valor)
    {
        pontuacaoAtual += valor;
        AtualizarUI();
    }

    public void AtualizarUI()
    {
        if (textoPontuacao != null)
            textoPontuacao.text = "" + pontuacaoAtual;
    }

    public int GetPontuacao()
    {
        return pontuacaoAtual;
    }
}
