﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

[System.Serializable]
public class MateriaPrimaCusto
{
    public string nomeMateria;
    public int quantidade;
}

[System.Serializable]
public class Movel
{
    public string nome;
    public Sprite imagem;
    public List<MateriaPrimaCusto> custo;
}

public class LojaMoveis : MonoBehaviour
{
    [Header("Referências")]
    public GameObject itemMovelPrefab; // prefab do item
    public Transform content;          // Content do Scroll View

    [Header("Móveis disponíveis")]
    public List<Movel> moveisDisponiveis = new List<Movel>();

    private void Start()
    {
        GerarListaMoveis();
    }

    void GerarListaMoveis()
    {
        if (itemMovelPrefab == null || content == null)
        {
            Debug.LogError("ItemMovelPrefab ou Content não foram arrastados no Inspector!");
            return;
        }

        foreach (var movel in moveisDisponiveis)
        {
            GameObject novoItem = Instantiate(itemMovelPrefab, content);

            // Encontrar elementos UI dentro do prefab
            Image img = novoItem.transform.Find("Imagem")?.GetComponent<Image>();
            TextMeshProUGUI txtNome = novoItem.transform.Find("TxtNome")?.GetComponent<TextMeshProUGUI>();
            TextMeshProUGUI txtPreco = novoItem.transform.Find("TxtPreco")?.GetComponent<TextMeshProUGUI>();
            Button botao = novoItem.transform.Find("BtnComprar")?.GetComponent<Button>();

            if (img != null) img.sprite = movel.imagem;
            if (txtNome != null) txtNome.text = movel.nome;

            // Monta texto do preço (custo por matéria prima)
            string custoTexto = "";
            foreach (var c in movel.custo)
                custoTexto += $"{c.quantidade}x {c.nomeMateria}, ";
            if (txtPreco != null) txtPreco.text = "Custa: " + custoTexto.TrimEnd(',', ' ');

            if (botao != null)
                botao.onClick.AddListener(() => ComprarMovel(movel));
        }
    }

    void ComprarMovel(Movel movel)
    {
        var bau = SlotBau.instancia; // pega o inventário do baú
        bool podeComprar = true;

        foreach (var c in movel.custo)
        {
            int qtdAtual = bau.GetQuantidadeMateria(c.nomeMateria);
            if (qtdAtual < c.quantidade)
            {
                podeComprar = false;
                Debug.Log($"Faltam {c.nomeMateria} para comprar {movel.nome}");
                break;
            }
        }

        if (podeComprar)
        {
            foreach (var c in movel.custo)
                bau.ConsumirMateria(c.nomeMateria, c.quantidade);

            Debug.Log($"Comprou {movel.nome}!");
        }
    }
}
