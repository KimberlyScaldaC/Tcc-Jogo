﻿using UnityEngine;
using TMPro;

public class SistemaDiaNoite : MonoBehaviour
{
    public static SistemaDiaNoite instancia; // Singleton
    public TextMeshProUGUI relogioText;  // arraste o TextMeshProUGUI aqui no Inspector
    public float tempoPorSegundos = 10f;  // tempo real que corresponde a 1 hora do jogo
    public SpriteRenderer[] ceus;        // todos os sprites que formam o céu
    public Color corDia = Color.cyan;
    public Color corNoite = Color.black;

    [HideInInspector]
    public int hora = 6;  // começa 6h00
    [HideInInspector]
    public int minuto = 0;

    public bool ehDia => hora >= 6 && hora < 18;

    private float timer = 0f;

    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= tempoPorSegundos)
        {
            timer = 0f;
            IncrementarHora(1);
        }
    }

    public void IncrementarHora(int minutos)
    {
        minuto = minuto+ minutos;
        if (minuto >= 60)
        {
            hora += minuto / 60;
            minuto %= 60;
            if (hora >= 24) hora %= 24;
        }
        AtualizarRelogio();
        AtualizarCeu();
    }

    public void AtualizarRelogio()
    {
        relogioText.text = string.Format("{0:00}:{1:00}", hora, minuto);
    }

    public void AtualizarCeu()
    {
        Color corAtual = ehDia ? corDia : corNoite;
        foreach (var c in ceus)
        {
            c.color = corAtual;
        }
    }

    // Método público para chamar quando o jogador dorme
    public void Dormir()
    {
        // avança o tempo para manhã (6h00)
        hora = 6;
        minuto = 0;
        AtualizarRelogio();
        AtualizarCeu();
    }

   

}
