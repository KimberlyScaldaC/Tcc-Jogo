using UnityEngine;

public class Configuracao : MonoBehaviour
{
    [Header("Painel do menu")]
    public GameObject configPanel; // painel de pausa

    [Header("M�sica")]
    public AudioSource musica; // arraste a m�sica de fundo aqui

    void Start()
    {
        // Garante que o menu come�a fechado
        if (configPanel != null)
            configPanel.SetActive(false);
    }

    // Alterna o menu aberto/fechado
    public void ToggleMenu()
    {
        if (configPanel == null) return;

        bool menuAberto = !configPanel.activeSelf; // inverte estado
        configPanel.SetActive(menuAberto);

        // Pausa ou retoma o jogo
        Time.timeScale = menuAberto ? 0f : 1f;
    }

    // Fecha o menu (usado pelo bot�o Voltar)
    public void FecharMenu()
    {
        if (configPanel == null) return;
        configPanel.SetActive(false);
        Time.timeScale = 1f;
    }

    // Liga a m�sica
    public void LigarSom()
    {
        AudioListener.volume = 1f;
        if (musica != null && !musica.isPlaying)
            musica.Play();
    }

    // Desliga a m�sica
    public void DesligarSom()
    {
        AudioListener.volume = 0f;
        if (musica != null)
            musica.Pause();
    }

    // Sair do jogo
    public void SairDoJogo()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit(); // funciona apenas no Build
    }
}
