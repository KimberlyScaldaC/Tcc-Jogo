using System.Collections.Generic;
using UnityEngine;

public class InventarioBau : MonoBehaviour
{
    public static InventarioBau instancia;

    [Header("Invent�rio do Ba�")]
    public GameObject inventarioUI;

    [Header("Slots do Ba� (6)")]
    public List<SlotBau> slots = new List<SlotBau>();

    [Header("Sprites das mat�rias-primas")]
    public Sprite madeiraSprite;
    public Sprite plasticoSprite;
    public Sprite papelSprite;
    public Sprite vidroSprite;
    public Sprite metalSprite;
    public Sprite eletronicoSprite;

    private void Awake()
    {
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);

        if (inventarioUI != null)
            inventarioUI.SetActive(false); // Come�a invis�vel
    }


    public void AtualizarInventarioDoBau()
    {
        var gm = GameManager.instancia;
        if (gm == null) return;

        (Sprite img, string nome, int quantidade)[] materias = {
            (madeiraSprite, "Madeira", gm.madeira),
            (plasticoSprite, "Pl�stico", gm.plastico),
            (papelSprite, "Papel", gm.papel),
            (vidroSprite, "Vidro", gm.vidro),
            (metalSprite, "Metal", gm.metal),
            (eletronicoSprite, "Eletr�nico", gm.eletronico)
        };

        for (int i = 0; i < slots.Count; i++)
        {
            if (i < materias.Length)
            {
                var (img, nome, qtd) = materias[i];
                if (slots[i] != null)
                    slots[i].AtualizarSlot(img, nome, qtd);
            }
        }
    }

    public void FechaBau()
    {
        if (inventarioUI != null)
        {
            BoxController.instancia.CloseBau();
        }
        
        
    }
}
