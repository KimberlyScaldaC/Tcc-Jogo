using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompController : MonoBehaviour
{
    public Animator animator;           // Animator da mesa/computador
    public GameObject menuComputer;     // Painel do menu da mesa
    public GameObject screen;           // Tela do computador (liga/desliga)

    private bool playerNearby = false;
    private bool isMenuOpen = false;


    private void Start()
    {
        menuComputer.SetActive(false);
        screen.SetActive(false); // come�a desligada
    }

    private void Update()
    {
        if (playerNearby && Input.GetKeyDown(KeyCode.E))
        {
            if (!isMenuOpen)
                OpenMenu();
            else
                CloseMenu();
        }
    }

    private void OpenMenu()
    {
        isMenuOpen = true;

        // Anima��o: tela liga
        animator.SetBool("isOn", true);

        // Mostra menu
        menuComputer.SetActive(true);

        // Mostra a tela ligada
        screen.SetActive(true);

        // Pausa o jogo se quiser
        Time.timeScale = 0f;
    }

    public void CloseMenu()
    {
        isMenuOpen = false;

        // Anima��o: tela desliga
        animator.SetBool("isOn", false);

        // Esconde menu
        menuComputer.SetActive(false);

        // Desliga a tela
        screen.SetActive(false);

        // Retoma o jogo
        Time.timeScale = 1f;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            playerNearby = true;

        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Personagem"))
        {
            playerNearby = false;

        }
    }
}