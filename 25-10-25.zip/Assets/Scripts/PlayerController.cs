﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    public static PlayerController instancia;

    public float speed = 3f;               // Velocidade do personagem
    public LayerMask paredeLayer;          // Layer das paredes
    private Rigidbody2D rb;
    private SpriteRenderer spriteRenderer;
    private Animator animator;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        float horizontal = Input.GetAxisRaw("Horizontal"); // -1, 0 ou 1

        Vector2 movimento = new Vector2(horizontal, 0) * speed * Time.deltaTime;

        // Raycast à frente para detectar parede
        if (horizontal != 0)
        {
            Vector2 direcao = new Vector2(horizontal, 0);
            RaycastHit2D hit = Physics2D.Raycast(rb.position, direcao, Mathf.Abs(movimento.x), paredeLayer);
            if (hit.collider == null)
            {
                rb.MovePosition(rb.position + movimento);
            }
        }

        // Animação
        bool parado = horizontal == 0;
        animator.SetBool("parado", parado);

        // Virar sprite
        if (horizontal > 0) spriteRenderer.flipX = false;
        else if (horizontal < 0) spriteRenderer.flipX = true;
    }

    // Para ver os Raycasts no Editor
    private void OnDrawGizmos()
    {
        if (rb != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawLine(rb.position, rb.position + Vector2.right * 1f);
        }
    }

    public void AumentarVelocidade(float valor)
    {
        PlayerController jogador = FindObjectOfType<PlayerController>();
        if (jogador != null)
        {
            jogador.speed += 2f; // aumenta a velocidade em 2
            Debug.Log("Velocidade aumentada! Nova velocidade: " + jogador.speed);
        }
    }
}
