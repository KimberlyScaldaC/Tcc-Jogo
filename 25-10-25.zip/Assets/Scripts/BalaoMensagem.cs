using UnityEngine;
using TMPro;

public class BalaoMensagem : MonoBehaviour
{
    public static BalaoMensagem instancia;
    public GameObject balao;
    public TextMeshProUGUI textoBalao;

    private void Awake()
    {
        instancia = this;
        balao.SetActive(false);
    }

    public void MostrarMensagem(string mensagem)
    {
        StopAllCoroutines(); // garante que mensagens antigas parem
        StartCoroutine(MostrarTemporariamente(mensagem));
    }

    private System.Collections.IEnumerator MostrarTemporariamente(string mensagem)
    {
        balao.SetActive(true);
        textoBalao.text = mensagem;
        yield return new WaitForSeconds(2f); // mostra por 2 segundos
        balao.SetActive(false);
    }
}
