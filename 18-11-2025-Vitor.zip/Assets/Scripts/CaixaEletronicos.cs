﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class CaixaEletronicos : MonoBehaviour
{
    public static CaixaEletronicos instancia;

    [Header("Sprites da Caixa")]
    public Sprite caixaVazia;
    public Sprite caixaCheia;

    private SpriteRenderer spriteRenderer;

    void Awake()
    {
        instancia = this;
    }

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        EsvaziarCaixa(); // começa vazia
    }

    // Coloca a caixa como cheia
    public void EncherCaixa()
    {
        if (spriteRenderer != null && caixaCheia != null)
        {
            spriteRenderer.sprite = caixaCheia;
        }
        else
        {
            Debug.LogWarning("SpriteRenderer ou caixaCheia não atribuídos!");
        }
    }

    // Coloca a caixa como vazia
    public void EsvaziarCaixa()
    {
        if (spriteRenderer != null && caixaVazia != null)
        {
            spriteRenderer.sprite = caixaVazia;
        }
        else
        {
            Debug.LogWarning("SpriteRenderer ou caixaVazia não atribuídos!");
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        EsvaziarCaixa();
        LixoColetavel lixo = other.GetComponent<LixoColetavel>();
        if (lixo != null && lixo.tipo == TipoLixo.Eletronico)
        {
            if (SistemaDiaNoite.instancia.hora == 18 && !GameManager.instancia.historinhaMostrada)
            {
                GameManager.instancia.historinhaMostrada = true;
                GameManager.instancia.SalvarProgresso();
                SceneManager.LoadScene("Scenes/LojaEletronicos", LoadSceneMode.Additive);

                // Quando a cena terminar de carregar, executa as ações
                SceneManager.sceneLoaded += AoCarregarCena;
            }
        }
    }

    private void AoCarregarCena(Scene cena, LoadSceneMode modo)
    {
        if (cena.name == "LojaEletronicos")
        {
            // Move tudo um pouco para cima, se quiser
            Vector3 deslocamento = new Vector3(0f, 10f, 0f);
            foreach (GameObject obj in cena.GetRootGameObjects())
                obj.transform.position += deslocamento;

            // 🔹 Desativa UI atual e pausa o jogo
            Configuracao menu = FindObjectOfType<Configuracao>();
            if (menu != null)
            {
                // Esconde UI
                if (menu.configPanel != null)
                    menu.configPanel.SetActive(false);
                if (menu.balao != null)
                    menu.balao.SetActive(false);

                // Pausa o jogo
                Time.timeScale = 0f;
            }

            // Remove o listener para evitar chamadas futuras
            SceneManager.sceneLoaded -= AoCarregarCena;
        }
    }

}
