﻿using UnityEngine;

public class MainHistoria : MonoBehaviour
{
    [Header("Menus principais")]
    public GameObject menuUI;           // Menu principal
    public GameObject storyManagerObj;  // Gameplay (diálogo)

    [Header("Menus adicionais")]
    public GameObject settingsUI;       // Painel de Configurações
    public GameObject controlsUI;       // Painel de Controles

    private bool somAtivado = true; // controle interno do som

    void Start()
    {
        menuUI.SetActive(true);
        storyManagerObj.SetActive(false);
        settingsUI.SetActive(false);
        controlsUI.SetActive(false);

        AudioListener.volume = 1f; // som ligado no início
        somAtivado = true;
    }

    // Botão "Play"
    public void PlayGame()
    {
        menuUI.SetActive(false);
        storyManagerObj.SetActive(true);
        settingsUI.SetActive(false);
        controlsUI.SetActive(false);
    }

    // Botão "Settings" no menu principal
    public void OpenSettings()
    {
        Debug.Log("Abrindo Configurações...");

        menuUI.SetActive(false);
        storyManagerObj.SetActive(false);
        settingsUI.SetActive(true);
        controlsUI.SetActive(false);
    }

    // Botão dentro de Settings para abrir os controles
    public void OpenControls()
    {
        Debug.Log("Abrindo Controles...");

        settingsUI.SetActive(false);
        controlsUI.SetActive(true);
    }

    // Botão dentro de Controls para voltar às Configurações
    public void BackToSettings()
    {
        controlsUI.SetActive(false);
        settingsUI.SetActive(true);
    }

    // Botão dentro de Settings para voltar ao menu inicial
    public void BackToMenu()
    {
        settingsUI.SetActive(false);
        menuUI.SetActive(true);
        controlsUI.SetActive(false);
    }

    // Botão Exit do menu principal
    public void QuitGame()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit();
    }

    // ============================
    // ⚡ Funções de ligar/desligar som
    // ============================

    // Desliga todo o som da cena
    public void MuteSound()
    {
        AudioListener.volume = 0f;
        somAtivado = false;
        Debug.Log("Som desligado!");
    }

    // Liga todo o som da cena
    public void UnmuteSound()
    {
        AudioListener.volume = 1f;
        somAtivado = true;
        Debug.Log("Som ligado!");
    }

    // (Opcional) Alternar som em um único botão
    public void ToggleSound()
    {
        if (somAtivado)
            MuteSound();
        else
            UnmuteSound();
    }
}
