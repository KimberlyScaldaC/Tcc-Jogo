using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject player;
    public GameObject menuUI; // aqui voc� vai arrastar o Canvas
    public GameObject inventario;
    public GameObject inventarioBau;



    void Start()
    {
        //menuUI.SetActive(true);

        menuUI.SetActive(true);
        player.SetActive(false);
        inventario.SetActive(false);
        inventarioBau.SetActive(false);
        


    }

    // Bot�o Play
    public void PlayGame()
    {
        SceneManager.LoadScene("Scenes/Intro");
        // Desliga o menu
        menuUI.SetActive(false); // esconde o menu
        player.SetActive(true);
        inventario.SetActive(true);


    }

    // Bot�o Settings
    public void OpenSettings()
    {
        Debug.Log("Abrindo Configura��es...");
        // Aqui voc� pode abrir um painel de op��es futuramente
    }

    // Bot�o Exit
    public void QuitGame()
    {
        Debug.Log("Saindo do jogo...");
        Application.Quit();

        // No editor n�o fecha, mas voc� v� a mensagem no Console
    }
}
