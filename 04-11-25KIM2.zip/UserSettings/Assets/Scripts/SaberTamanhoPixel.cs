using UnityEngine;

public class ObterTamanhoPixelSprite : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null && spriteRenderer.sprite != null)
        {
            Vector2 tamanhoEmPixels = spriteRenderer.sprite.rect.size;
            Debug.Log("Tamanho em pixels: " + tamanhoEmPixels.x + "x" + tamanhoEmPixels.y);
        }
    }
}
