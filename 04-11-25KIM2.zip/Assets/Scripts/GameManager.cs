using UnityEngine;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager instancia;

    [Header("Caixa Eletr�nicos")]
    public bool lixoEletronicoNaCaixa = false;
    public bool historinhaMostrada = false;

    [Header("Refer�ncias de HUD")]
    public GameObject inventarioHUD;
    public GameObject menuResultadosDia;

    [Header("Lixos reciclados por tipo")]
    public int recicladosOrganicoQuant;
    public int recicladosPlasticoQuant;
    public int recicladosPapelQuant;
    public int recicladosVidroQuant;
    public int recicladosMetalQuant;
    public int recicladosEletronicoQuant;
    public int recicladosMadeiraQuant;
    public int recicladosPilhaQuant;

    [Header("Lixos reciclados por tipo")]
    public int recicladosOrganico;
    public int recicladosPlastico;
    public int recicladosPapel;
    public int recicladosVidro;
    public int recicladosMetal;
    public int recicladosEletronico;
    public int recicladosMadeira;
    public int recicladosPilha;

    [Header("Mat�ria-prima obtida")]
    public int madeira;
    public int plastico;
    public int papel;
    public int vidro;
    public int metal;
    public int eletronico;

    [Header("Pontos obtida")]
    public int pontos;

    [Header("Pontos obtidos na Compra Moveis")]
    public int pontosMoveis;

    void Start()
    {
        lixoEletronicoNaCaixa = false;
        historinhaMostrada = false;
    }

    private void Awake()
    {
        if (instancia == null)
        {
            instancia = this;
            DontDestroyOnLoad(gameObject);

            lixoEletronicoNaCaixa = PlayerPrefs.GetInt("lixoEletronicoNaCaixa", 0) == 1;
            historinhaMostrada = PlayerPrefs.GetInt("historinhaMostrada", 0) == 1;

        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SomarPontos(int valor)
    {
        pontos = pontos + valor;
    }

    public void MostrarPontos()
    {
        GerenciadorPontuacao.instancia.AdicionarPontos(pontos);
    }

    public void MostrarCoisa()
    {
        inventarioHUD.SetActive(true);
        menuResultadosDia.SetActive(true);
    }

    public void PontoMoveis(int valor)
    {
        pontosMoveis = pontosMoveis+valor;
    }

    public void NaoMostrarCoisa()
    {
        inventarioHUD.SetActive(false);
        menuResultadosDia.SetActive(false);
    }

    public void SalvarProgresso()
    {
        PlayerPrefs.SetInt("lixoEletronicoNaCaixa", lixoEletronicoNaCaixa ? 1 : 0);
        PlayerPrefs.SetInt("historinhaMostrada", historinhaMostrada ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void RegistrarReciclagem(TipoLixo tipo)
    {
        switch (tipo)
        {
            case TipoLixo.Organico:
                recicladosOrganicoQuant++;
                recicladosOrganico += 100;
                break;

            case TipoLixo.Plastico:
                recicladosPlasticoQuant++;
                recicladosPlastico += 300;
                plastico += 7;
                break;

            case TipoLixo.Papel:
                recicladosPapelQuant++;
                recicladosPapel += 150;
                papel += 6;
                break;

            case TipoLixo.Vidro:
                recicladosVidroQuant++;
                recicladosVidro += 200;
                vidro += 3;
                break;

            case TipoLixo.Metal:
                recicladosMetalQuant++;
                recicladosMetal += 500;
                metal += 4;
                break;

            case TipoLixo.Eletronico:
                recicladosEletronicoQuant++;
                recicladosEletronico += 500;
                eletronico += 5;
                break;

            case TipoLixo.Madeira:
                recicladosMadeiraQuant++;
                recicladosMadeira += 250;
                madeira += 10;
                break;
                
            case TipoLixo.Pilha:
                recicladosPilhaQuant++;
                recicladosPilha += 400;
                break;
        }
    }

    public void ResetarEstatisticasDia()
    {
        recicladosOrganico = 0;
        recicladosPlastico = 0;
        recicladosPapel = 0;
        recicladosVidro = 0;
        recicladosMetal = 0;
        recicladosEletronico = 0;
        recicladosMadeira = 0;
        recicladosPilha = 0;

        recicladosOrganicoQuant = 0;
        recicladosPlasticoQuant = 0;
        recicladosPapelQuant = 0;
        recicladosVidroQuant = 0;
        recicladosMetalQuant = 0;
        recicladosEletronicoQuant = 0;
        recicladosMadeiraQuant = 0;
        recicladosPilhaQuant = 0;

        madeira = 0;
        plastico = 0;
        papel = 0;
        vidro = 0;
        metal = 0;
        eletronico = 0;

        pontos = 0;
        pontosMoveis = 0;
    }

}
