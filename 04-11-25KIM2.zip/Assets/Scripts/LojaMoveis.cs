﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

[System.Serializable]
public class MateriaPrimaCusto
{
    public string nomeMateria;
    public int quantidade;
}

[System.Serializable]
public class Movel
{
    public string nome;
    public Sprite imagem;
    public List<MateriaPrimaCusto> custo;
    public int pontos;
    public GameObject prefabNaCasa;
}

public class LojaMoveis : MonoBehaviour
{
    public static LojaMoveis instancia;

    [Header("Referências")]
    public GameObject itemMovelPrefab; // prefab do item
    public Transform content;          // Content do Scroll View

    [Header("MateriasPrimas")]
    public GameObject InventarioMateriaPrima;

    [Header("Móveis disponíveis")]
    public List<Movel> moveisDisponiveis = new List<Movel>();

    [Header("Quantidade de Matéria-Prima do Jogador")]
    public int madeira;
    public int plastico;
    public int papel;
    public int vidro;
    public int metal;
    public int eletronico;

    [Header("Sprites das matérias-primas")]
    public Sprite madeiraSprite;
    public Sprite plasticoSprite;
    public Sprite papelSprite;
    public Sprite vidroSprite;
    public Sprite metalSprite;
    public Sprite eletronicoSprite;

    private void Awake()
    {
        if (instancia == null) instancia = this;
    }

    private void Start()
    {
        GerarListaMoveis();
    }

    void GerarListaMoveis()
    {
        if (itemMovelPrefab == null || content == null)
        {
            Debug.LogError("ItemMovelPrefab ou Content não foram arrastados no Inspector!");
            return;
        }

        foreach (var movel in moveisDisponiveis)
        {
            InventarioMateriaPrima.SetActive(true);
            GameObject novoItem = Instantiate(itemMovelPrefab, content);

            Image img = novoItem.transform.Find("Imagem")?.GetComponent<Image>();
            TextMeshProUGUI txtNome = novoItem.transform.Find("TxtNome")?.GetComponent<TextMeshProUGUI>();
            TextMeshProUGUI txtPreco = novoItem.transform.Find("TxtPreco")?.GetComponent<TextMeshProUGUI>();
            TextMeshProUGUI txtPonto = novoItem.transform.Find("TxtPonto")?.GetComponent<TextMeshProUGUI>();
            Button botao = novoItem.transform.Find("BtnComprar")?.GetComponent<Button>();

            if (img != null) img.sprite = movel.imagem;
            if (txtNome != null) txtNome.text = movel.nome;

            if (txtPonto != null) txtPonto.text = $"+{movel.pontos}";
        
            string custoTexto = "";
            foreach (var c in movel.custo)
                custoTexto += $"{c.quantidade}x {c.nomeMateria}\n";
            if (txtPreco != null) txtPreco.text = "Preço: \n" + custoTexto.TrimEnd('\n');

            if (botao != null)
                botao.onClick.AddListener(() => ComprarMovel(movel));
        }
    }

    void ComprarMovel(Movel movel)
    {
        // Verifica se tem matéria-prima suficiente
        foreach (var c in movel.custo)
        {
            int qtdAtual = GetQuantidadeMateria(c.nomeMateria);
            if (qtdAtual < c.quantidade)
            {
                Debug.Log($"❌ Faltam {c.nomeMateria} para comprar {movel.nome}");
                return;
            }
        }

        // Desconta matérias-primas e atualiza SlotBau
        foreach (var c in movel.custo)
            RetiraMateriaPrima(c.nomeMateria, c.quantidade);

        // Dá pontos
        GameManager.instancia.PontoMoveis(movel.pontos);

        // Ativa móvel na cena
        if (movel.prefabNaCasa != null)
            movel.prefabNaCasa.SetActive(true);

        Debug.Log($"✅ {movel.nome} comprado e ativado na casa!");
    }

    public void AtualizarMateriaPrima(string nome, int quantidade)
    {
        // Pode ser usado para sincronizar UI ou salvar dados
        Debug.Log($"Loja recebeu atualização: {quantidade}x {nome}");
        switch (nome)
        {
            case "Madeira":
                madeira += quantidade;
                break;
            case "Plástico":
                plastico += quantidade;
                break;
            case "Papel":
                papel += quantidade;
                break;
            case "Vidro":
                vidro += quantidade;
                break;
            case "Metal":
                metal += quantidade;
                break;
            case "Eletrônico":
                eletronico += quantidade;
                break;

        }
    }

    public int GetQuantidadeMateria(string nome)
    {
        switch (nome)
        {
            case "Madeira": return madeira;
            case "Plástico": return plastico;
            case "Papel": return papel;
            case "Vidro": return vidro;
            case "Metal": return metal;
            case "Eletrônico": return eletronico;
        }
        return 0;
    }

    public void RetiraMateriaPrima(string nome, int quantidade)
    {
        Sprite sprite = GetSprite(nome);

        switch (nome)
        {
            case "Madeira": madeira -= quantidade; break;
            case "Plástico": plastico -= quantidade; break;
            case "Papel": papel -= quantidade; break;
            case "Vidro": vidro -= quantidade; break;
            case "Metal": metal -= quantidade; break;
            case "Eletrônico": eletronico -= quantidade; break;
        }


        SlotBau.instancia.ConsumirMateria(nome, quantidade);

        Debug.Log($"Retirado {quantidade}x {nome}");
    }

    private Sprite GetSprite(string nome)
    {
        switch (nome)
        {
            case "Madeira": return madeiraSprite;
            case "Plástico": return plasticoSprite;
            case "Papel": return papelSprite;
            case "Vidro": return vidroSprite;
            case "Metal": return metalSprite;
            case "Eletrônico": return eletronicoSprite;
        }
        return null;
    }


}
