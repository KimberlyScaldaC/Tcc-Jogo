﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class StoryDialogue : MonoBehaviour
{
    public TextMeshProUGUI dialogueText;  // DialogueText do balão
    public GameObject balloonImage;       // BalloonImage
    public float dialogueSpeed = 0.05f;   // velocidade do texto

    private string[] dialogues = new string[]
    {
        "Oi! Acabei de me mudar para uma nova cidade.",
        "Comprei uma casa.",
        "Mas o quintal está cheio de lixo e entulho...",
        "Quero limpar tudo e reciclar o que for possível.",
        "Vamos nessa?"
    };

    private int index = 0; // índice da fala atual

    void Start()
    {
        balloonImage.SetActive(true);
        StartCoroutine(ShowDialogue());
    }

    IEnumerator ShowDialogue()
    {
        dialogueText.text = "";
        foreach (char c in dialogues[index])
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(dialogueSpeed);
        }
    }

    // Botão Next
    public void NextDialogue()
    {
        index++;
        if (index < dialogues.Length)
        {
            StopAllCoroutines();
            StartCoroutine(ShowDialogue());
        }
        else
        {
            // Fim do diálogo → ir para a cena do jogo
            SceneManager.LoadScene("Tcc");
        }
    }

    // Botão Skip
    public void SkipStory()
    {
        SceneManager.LoadScene("Tcc");
    }
}
