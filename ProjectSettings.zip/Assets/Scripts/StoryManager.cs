using UnityEngine;
using UnityEngine.SceneManagement;

public class StoryManager : MonoBehaviour
{
    public float storyDuration = 5f; // tempo em segundos para a hist�ria

    void Start()
    {
        // Ap�s storyDuration segundos, vai para a cena do jogo
        Invoke("StartGame", storyDuration);
    }

    void StartGame()
    {
        SceneManager.LoadScene("GameScene"); // nome da cena do jogo
    }
}
